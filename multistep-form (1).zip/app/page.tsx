import FormWrapper from "@/components/form-wrapper"

export default function FormPage() {
  return (
    <main className="container py-5">
      <h1 className="text-center mb-4">Project Approval Process</h1>
      <FormWrapper />
    </main>
  )
}
