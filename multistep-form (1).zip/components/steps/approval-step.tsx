"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import ProfessionalUserSearch from "../approvals/professional-user-search"
import TaskManager, { type Task } from "../approvals/task-manager"
import type { User, UserApproval } from "../../lib/mock-data"

const approvalSchema = z.object({
  irtCoordinator: z.string().min(2, { message: "IRT Coordinator name is required" }),
  coordinatorEmail: z.string().email({ message: "Invalid email address" }),
  processDate: z.string({ required_error: "Process date is required" }),
  approvals: z.array(z.any()).min(1, { message: "At least one team member must be added for approval" }),
  allApproved: z.boolean().refine((val) => val === true, {
    message: "All team members must approve before completing the process",
  }),
})

type ApprovalValues = z.infer<typeof approvalSchema>

interface ApprovalStepProps {
  onComplete: (data: ApprovalValues) => void
  existingData: ApprovalValues | null
}

export default function ApprovalStep({ onComplete, existingData }: ApprovalStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [approvals, setApprovals] = useState<UserApproval[]>(existingData?.approvals || [])
  const [currentUserId] = useState("1") // Mock current user ID
  const [userTasks, setUserTasks] = useState<{ [userId: string]: Task[] }>({})

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
  } = useForm<ApprovalValues>({
    resolver: zodResolver(approvalSchema),
    defaultValues: existingData || {
      irtCoordinator: "",
      coordinatorEmail: "",
      processDate: new Date().toISOString().split("T")[0],
      approvals: [],
      allApproved: false,
    },
  })

  const updateFormApprovals = (newApprovals: UserApproval[]) => {
    setApprovals(newApprovals)
    setValue("approvals", newApprovals)
    setValue("allApproved", newApprovals.length > 0 && newApprovals.every((a) => a.status === "approved"))
    trigger(["approvals", "allApproved"])
  }

  const handleUserAdd = (user: User) => {
    const newApproval: UserApproval = {
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      team: user.team,
      role: user.role,
      status: "pending",
      comment: "",
      canEdit: user.id === currentUserId,
    }

    updateFormApprovals([...approvals, newApproval])
    // Initialize empty tasks for new user
    setUserTasks((prev) => ({ ...prev, [user.id]: [] }))
  }

  const handleApprovalUpdate = (userId: string, status: "approved" | "rejected", comment: string) => {
    const updatedApprovals = approvals.map((approval) =>
      approval.userId === userId
        ? {
            ...approval,
            status,
            comment,
            approvedAt: new Date().toISOString(),
            canEdit: false,
          }
        : approval,
    )
    updateFormApprovals(updatedApprovals)
  }

  const handleUserRemove = (userId: string) => {
    const updatedApprovals = approvals.filter((approval) => approval.userId !== userId)
    updateFormApprovals(updatedApprovals)
    // Remove tasks for removed user
    setUserTasks((prev) => {
      const newTasks = { ...prev }
      delete newTasks[userId]
      return newTasks
    })
  }

  const handleTasksUpdate = (userId: string, tasks: Task[]) => {
    setUserTasks((prev) => ({ ...prev, [userId]: tasks }))
  }

  async function onSubmit(values: ApprovalValues) {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      // Include tasks in the submission data
      const dataWithTasks = {
        ...values,
        userTasks,
      }
      onComplete(dataWithTasks)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const approvalStats = {
    total: approvals.length,
    approved: approvals.filter((a) => a.status === "approved").length,
    pending: approvals.filter((a) => a.status === "pending").length,
  }

  const addedUserIds = approvals.map((a) => a.userId)

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Coordinator Information */}
        <div className="card border-0 shadow-sm mb-4">
          <div className="card-header bg-white border-bottom">
            <h6 className="mb-0 fw-medium">IRT Coordinator Information</h6>
          </div>
          <div className="card-body">
            <div className="row g-4">
              <div className="col-md-4">
                <label htmlFor="irtCoordinator" className="form-label fw-medium text-dark">
                  Coordinator Name
                </label>
                <input
                  id="irtCoordinator"
                  type="text"
                  className={`form-control ${errors.irtCoordinator ? "is-invalid" : ""}`}
                  placeholder="Enter your full name"
                  {...register("irtCoordinator")}
                />
                {errors.irtCoordinator && <div className="invalid-feedback">{errors.irtCoordinator.message}</div>}
              </div>

              <div className="col-md-4">
                <label htmlFor="coordinatorEmail" className="form-label fw-medium text-dark">
                  Email Address
                </label>
                <input
                  id="coordinatorEmail"
                  type="email"
                  className={`form-control ${errors.coordinatorEmail ? "is-invalid" : ""}`}
                  placeholder="your.email@company.com"
                  {...register("coordinatorEmail")}
                />
                {errors.coordinatorEmail && <div className="invalid-feedback">{errors.coordinatorEmail.message}</div>}
              </div>

              <div className="col-md-4">
                <label htmlFor="processDate" className="form-label fw-medium text-dark">
                  Process Date
                </label>
                <input
                  id="processDate"
                  type="date"
                  className={`form-control ${errors.processDate ? "is-invalid" : ""}`}
                  {...register("processDate")}
                />
                {errors.processDate && <div className="invalid-feedback">{errors.processDate.message}</div>}
              </div>
            </div>
          </div>
        </div>

        {/* User Search */}
        <div className="card border-0 shadow-sm mb-4">
          <div className="card-body">
            <ProfessionalUserSearch onUserAdd={handleUserAdd} addedUserIds={addedUserIds} />
            {errors.approvals && <div className="text-danger small">{errors.approvals.message}</div>}
          </div>
        </div>

        {/* Team Members with Tasks */}
        {approvals.length > 0 && (
          <div className="mb-4">
            {approvals.map((approval) => (
              <div key={approval.userId} className="card border-0 shadow-sm mb-3">
                <div className="card-header bg-light">
                  <div className="d-flex align-items-center justify-content-between">
                    <div className="d-flex align-items-center">
                      <div
                        className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3 fw-medium"
                        style={{ width: "40px", height: "40px", fontSize: "14px" }}
                      >
                        {approval.userName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()}
                      </div>
                      <div>
                        <h6 className="mb-0">{approval.userName}</h6>
                        <div className="text-muted small">
                          {approval.role} • {approval.team}
                        </div>
                      </div>
                    </div>
                    <div className="d-flex align-items-center gap-2">
                      <span
                        className={`badge ${
                          approval.status === "approved"
                            ? "bg-success"
                            : approval.status === "rejected"
                              ? "bg-danger"
                              : "bg-warning"
                        }`}
                      >
                        {approval.status === "pending"
                          ? "Pending"
                          : approval.status === "approved"
                            ? "Approved"
                            : "Rejected"}
                      </span>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleUserRemove(approval.userId)}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  {/* Approval Actions */}
                  {approval.canEdit && approval.status === "pending" && (
                    <div className="mb-3">
                      <div className="d-flex gap-2 mb-3">
                        <button
                          type="button"
                          className="btn btn-success"
                          onClick={() => handleApprovalUpdate(approval.userId, "approved", approval.comment)}
                        >
                          <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                            check
                          </span>
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-outline-danger"
                          onClick={() => handleApprovalUpdate(approval.userId, "rejected", approval.comment)}
                        >
                          <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                            close
                          </span>
                          Reject
                        </button>
                      </div>
                      <textarea
                        className="form-control"
                        rows={2}
                        placeholder="Add your comments..."
                        value={approval.comment}
                        onChange={(e) => {
                          const updatedApprovals = approvals.map((a) =>
                            a.userId === approval.userId ? { ...a, comment: e.target.value } : a,
                          )
                          setApprovals(updatedApprovals)
                        }}
                      />
                    </div>
                  )}

                  {/* Display comment if not editable */}
                  {(!approval.canEdit || approval.status !== "pending") && approval.comment && (
                    <div className="mb-3">
                      <label className="form-label small text-muted">Comment</label>
                      <div className="bg-light p-3 rounded">{approval.comment}</div>
                    </div>
                  )}

                  {/* Task Manager */}
                  <TaskManager
                    userId={approval.userId}
                    userName={approval.userName}
                    tasks={userTasks[approval.userId] || []}
                    onTasksUpdate={handleTasksUpdate}
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Process Status */}
        {approvals.length > 0 && (
          <div className={`alert ${approvalStats.pending > 0 ? "alert-warning" : "alert-success"} border-0 mb-4`}>
            <div className="d-flex align-items-center">
              <span className="material-icons me-3" style={{ fontSize: "24px" }}>
                {approvalStats.pending > 0 ? "schedule" : "check_circle"}
              </span>
              <div>
                <div className="fw-medium">
                  {approvalStats.pending > 0 ? "Approval Process In Progress" : "All Approvals Complete"}
                </div>
                <div className="small text-muted mt-1">
                  {approvalStats.approved} of {approvalStats.total} team members have approved
                  {approvalStats.pending > 0 && " • Waiting for remaining responses"}
                </div>
                {errors.allApproved && <div className="text-danger small mt-2">{errors.allApproved.message}</div>}
              </div>
            </div>
          </div>
        )}

        {/* Submit Button */}
        <div className="d-flex justify-content-end">
          <button type="button" className="btn btn-primary px-4" disabled={isSubmitting || approvalStats.pending > 0}>
            {isSubmitting ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Processing...
              </>
            ) : (
              <>
                <span className="material-icons me-2" style={{ fontSize: "18px" }}>
                  task_alt
                </span>
                Complete IRT Process
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
