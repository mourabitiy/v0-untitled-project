"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import DataDisplay from "../review/data-display"

const requestReviewSchema = z
  .object({
    reviewerName: z.string().min(2, { message: "Reviewer name is required" }),
    reviewerEmail: z.string().email({ message: "Invalid email address" }),
    reviewDate: z.string().min(1, { message: "Review date is required" }),
    decision: z.enum(["approve", "reject"], { required_error: "Please select approve or reject" }),
    approvalComment: z.string().optional(),
    rejectionReason: z.string().optional(),
  })
  .refine(
    (data) => {
      if (data.decision === "approve" && (!data.approvalComment || data.approvalComment.trim().length === 0)) {
        return false
      }
      return true
    },
    {
      message: "Approval comment is required when approving",
      path: ["approvalComment"],
    },
  )
  .refine(
    (data) => {
      if (data.decision === "reject" && (!data.rejectionReason || data.rejectionReason.trim().length === 0)) {
        return false
      }
      return true
    },
    {
      message: "Rejection reason is required when rejecting",
      path: ["rejectionReason"],
    },
  )

type RequestReviewValues = z.infer<typeof requestReviewSchema>

interface RequestReviewStepProps {
  onComplete: (data: RequestReviewValues) => void
  onReject: (data: RequestReviewValues) => void
  existingData: RequestReviewValues | null
  initializationData: any
}

export default function RequestReviewStep({
  onComplete,
  onReject,
  existingData,
  initializationData,
}: RequestReviewStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<RequestReviewValues>({
    resolver: zodResolver(requestReviewSchema),
    defaultValues: existingData || {
      reviewerName: "",
      reviewerEmail: "",
      reviewDate: new Date().toISOString().split("T")[0],
      decision: "approve",
      approvalComment: "",
      rejectionReason: "",
    },
  })

  const decision = watch("decision")

  async function onSubmit(values: RequestReviewValues) {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (values.decision === "approve") {
        onComplete(values)
      } else {
        onReject(values)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="row g-4">
      {/* Display submitted data */}
      <div className="col-12">{initializationData && <DataDisplay data={initializationData} />}</div>

      {/* Review form */}
      <div className="col-12">
        <div className="card">
          <div className="card-header bg-warning text-dark">
            <div className="d-flex align-items-center">
              <span className="material-icons me-2">rate_review</span>
              <h5 className="mb-0">Review Decision</h5>
            </div>
          </div>
          <div className="card-body">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="row g-3 mb-3">
                <div className="col-md-6">
                  <label htmlFor="reviewerName" className="form-label">
                    Reviewer Name
                  </label>
                  <input
                    id="reviewerName"
                    type="text"
                    className={`form-control ${errors.reviewerName ? "is-invalid" : ""}`}
                    placeholder="Your name"
                    {...register("reviewerName")}
                  />
                  {errors.reviewerName && <div className="invalid-feedback">{errors.reviewerName.message}</div>}
                </div>

                <div className="col-md-6">
                  <label htmlFor="reviewerEmail" className="form-label">
                    Reviewer Email
                  </label>
                  <input
                    id="reviewerEmail"
                    type="email"
                    className={`form-control ${errors.reviewerEmail ? "is-invalid" : ""}`}
                    placeholder="your.email@company.com"
                    {...register("reviewerEmail")}
                  />
                  {errors.reviewerEmail && <div className="invalid-feedback">{errors.reviewerEmail.message}</div>}
                </div>

                <div className="col-md-6">
                  <label htmlFor="reviewDate" className="form-label">
                    Review Date
                  </label>
                  <input
                    id="reviewDate"
                    type="date"
                    className={`form-control ${errors.reviewDate ? "is-invalid" : ""}`}
                    {...register("reviewDate")}
                  />
                  {errors.reviewDate && <div className="invalid-feedback">{errors.reviewDate.message}</div>}
                </div>
              </div>

              {/* Decision Section */}
              <div className="mb-4">
                <label className="form-label">Review Decision</label>
                <div className="row g-3">
                  <div className="col-md-6">
                    <div className="card border-success">
                      <div className="card-body text-center">
                        <div className="form-check">
                          <input
                            id="approve"
                            type="radio"
                            className="form-check-input"
                            value="approve"
                            {...register("decision")}
                          />
                          <label className="form-check-label w-100" htmlFor="approve">
                            <span className="material-icons text-success d-block mb-2" style={{ fontSize: "32px" }}>
                              check_circle
                            </span>
                            <strong>Approve</strong>
                            <div className="small text-muted">Proceed to next step</div>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="card border-danger">
                      <div className="card-body text-center">
                        <div className="form-check">
                          <input
                            id="reject"
                            type="radio"
                            className="form-check-input"
                            value="reject"
                            {...register("decision")}
                          />
                          <label className="form-check-label w-100" htmlFor="reject">
                            <span className="material-icons text-danger d-block mb-2" style={{ fontSize: "32px" }}>
                              cancel
                            </span>
                            <strong>Reject</strong>
                            <div className="small text-muted">Return to previous step</div>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {errors.decision && <div className="text-danger small mt-1">{errors.decision.message}</div>}
              </div>

              {/* Conditional Comment/Reason Fields */}
              {decision === "approve" && (
                <div className="mb-3">
                  <label htmlFor="approvalComment" className="form-label">
                    <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                      comment
                    </span>
                    Approval Comment
                  </label>
                  <textarea
                    id="approvalComment"
                    className={`form-control ${errors.approvalComment ? "is-invalid" : ""}`}
                    placeholder="Please provide comments for approval..."
                    rows={3}
                    {...register("approvalComment")}
                  ></textarea>
                  <div className="form-text">Explain why you are approving this project</div>
                  {errors.approvalComment && <div className="invalid-feedback">{errors.approvalComment.message}</div>}
                </div>
              )}

              {decision === "reject" && (
                <div className="mb-3">
                  <label htmlFor="rejectionReason" className="form-label">
                    <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                      report_problem
                    </span>
                    Rejection Reason
                  </label>
                  <textarea
                    id="rejectionReason"
                    className={`form-control ${errors.rejectionReason ? "is-invalid" : ""}`}
                    placeholder="Please provide the reason for rejection..."
                    rows={3}
                    {...register("rejectionReason")}
                  ></textarea>
                  <div className="form-text">Explain what needs to be changed or corrected</div>
                  {errors.rejectionReason && <div className="invalid-feedback">{errors.rejectionReason.message}</div>}
                </div>
              )}

              <div className="d-flex justify-content-end">
                <button
                  type="submit"
                  className={`btn ${decision === "approve" ? "btn-success" : "btn-danger"}`}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Processing...
                    </>
                  ) : (
                    <>
                      <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                        {decision === "approve" ? "check" : "close"}
                      </span>
                      {decision === "approve" ? "Approve & Continue" : "Reject & Return"}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
