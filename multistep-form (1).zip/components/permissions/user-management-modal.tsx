"use client"

import { useState } from "react"
import { searchUsers, type User } from "../../lib/mock-data"
import { SIMPLE_ROLES, getRoleById, type UserRole } from "../../lib/simple-permissions"

interface UserManagementModalProps {
  isOpen: boolean
  onClose: () => void
  userRoles: UserRole[]
  onUserRolesUpdate: (roles: UserRole[]) => void
}

export default function UserManagementModal({
  isOpen,
  onClose,
  userRoles,
  onUserRolesUpdate,
}: UserManagementModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [selectedRole, setSelectedRole] = useState("reviewer")

  if (!isOpen) return null

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    if (query.length >= 2) {
      const existingUserIds = userRoles.map((ur) => ur.userId)
      const results = searchUsers(query).filter((user) => !existingUserIds.includes(user.id))
      setSearchResults(results.slice(0, 5))
    } else {
      setSearchResults([])
    }
  }

  const handleAddUser = (user: User) => {
    const newUserRole: UserRole = {
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      role: selectedRole,
      assignedBy: "Current User",
      assignedAt: new Date().toISOString(),
      isActive: true,
    }

    onUserRolesUpdate([...userRoles, newUserRole])
    setSearchQuery("")
    setSearchResults([])
  }

  const handleRemoveUser = (userId: string) => {
    onUserRolesUpdate(userRoles.filter((ur) => ur.userId !== userId))
  }

  const handleRoleChange = (userId: string, newRole: string) => {
    onUserRolesUpdate(userRoles.map((ur) => (ur.userId === userId ? { ...ur, role: newRole } : ur)))
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50"
        style={{ zIndex: 1050 }}
        onClick={onClose}
      />

      {/* Modal */}
      <div
        className="position-fixed top-50 start-50 translate-middle bg-white rounded-4 shadow-lg"
        style={{
          zIndex: 1051,
          width: "90%",
          maxWidth: "600px",
          maxHeight: "80vh",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div className="d-flex align-items-center justify-content-between p-4 border-bottom">
          <div>
            <h5 className="mb-0 fw-semibold">Team Members</h5>
            <div className="text-muted small">{userRoles.length} members</div>
          </div>
          <button type="button" className="btn-close" onClick={onClose} aria-label="Close" />
        </div>

        {/* Content */}
        <div style={{ maxHeight: "60vh", overflowY: "auto" }}>
          {/* Add User Section */}
          <div className="p-4 bg-light border-bottom">
            <div className="row g-3 align-items-end">
              <div className="col-7">
                <label className="form-label small fw-medium text-dark mb-2">Add Team Member</label>
                <div className="position-relative">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by name or email..."
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                  />

                  {/* Search Results */}
                  {searchResults.length > 0 && (
                    <div
                      className="position-absolute w-100 bg-white border rounded-3 shadow-sm mt-1"
                      style={{ zIndex: 1000 }}
                    >
                      {searchResults.map((user) => (
                        <div
                          key={user.id}
                          className="d-flex align-items-center justify-content-between p-3 border-bottom hover-bg-light"
                          style={{ cursor: "pointer" }}
                        >
                          <div className="d-flex align-items-center">
                            <div
                              className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3 fw-medium"
                              style={{ width: "32px", height: "32px", fontSize: "12px" }}
                            >
                              {user.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .toUpperCase()}
                            </div>
                            <div>
                              <div className="fw-medium">{user.name}</div>
                              <div className="text-muted small">{user.email}</div>
                            </div>
                          </div>
                          <button type="button" className="btn btn-sm btn-primary" onClick={() => handleAddUser(user)}>
                            Add
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="col-5">
                <label className="form-label small fw-medium text-dark mb-2">Default Role</label>
                <select className="form-select" value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
                  {SIMPLE_ROLES.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Team Members List */}
          <div className="p-4">
            {userRoles.length > 0 ? (
              <div className="d-flex flex-column gap-3">
                {userRoles.map((userRole) => {
                  const role = getRoleById(userRole.role)
                  return (
                    <div
                      key={userRole.userId}
                      className="d-flex align-items-center justify-content-between p-3 bg-light rounded-3"
                    >
                      <div className="d-flex align-items-center">
                        <div
                          className="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-3 fw-medium"
                          style={{ width: "40px", height: "40px", fontSize: "14px" }}
                        >
                          {userRole.userName
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </div>
                        <div>
                          <div className="fw-medium">{userRole.userName}</div>
                          <div className="text-muted small">{userRole.userEmail}</div>
                        </div>
                      </div>

                      <div className="d-flex align-items-center gap-2">
                        <select
                          className="form-select form-select-sm"
                          style={{ width: "140px" }}
                          value={userRole.role}
                          onChange={(e) => handleRoleChange(userRole.userId, e.target.value)}
                        >
                          {SIMPLE_ROLES.map((role) => (
                            <option key={role.id} value={role.id}>
                              {role.name}
                            </option>
                          ))}
                        </select>

                        <button
                          type="button"
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => handleRemoveUser(userRole.userId)}
                        >
                          <span className="material-icons" style={{ fontSize: "16px" }}>
                            delete
                          </span>
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-5">
                <span className="material-icons text-muted mb-3" style={{ fontSize: "48px" }}>
                  group_add
                </span>
                <div className="text-muted">No team members added yet</div>
                <div className="text-muted small">Search and add users to get started</div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-top bg-light d-flex justify-content-end">
          <button type="button" className="btn btn-primary" onClick={onClose}>
            Done
          </button>
        </div>
      </div>
    </>
  )
}
