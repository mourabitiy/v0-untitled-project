"use client"

import { useState } from "react"
import { searchUsers, type User } from "../../lib/mock-data"
import { SIMPLE_ROLES, getRoleById, type UserRole } from "../../lib/simple-permissions"

interface SimpleUserManagementProps {
  userRoles: UserRole[]
  onUserRolesUpdate: (roles: UserRole[]) => void
}

export default function SimpleUserManagement({ userRoles, onUserRolesUpdate }: SimpleUserManagementProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [selectedRole, setSelectedRole] = useState("")
  const [showSearch, setShowSearch] = useState(false)

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    if (query.length >= 2) {
      const existingUserIds = userRoles.map((ur) => ur.userId)
      const results = searchUsers(query).filter((user) => !existingUserIds.includes(user.id))
      setSearchResults(results)
    } else {
      setSearchResults([])
    }
  }

  const handleUserSelect = (user: User) => {
    setSelectedUser(user)
    setSearchQuery(user.name)
    setSearchResults([])
  }

  const handleAddUser = () => {
    if (!selectedUser || !selectedRole) return

    const newUserRole: UserRole = {
      userId: selectedUser.id,
      userName: selectedUser.name,
      userEmail: selectedUser.email,
      role: selectedRole,
      assignedBy: "Current User",
      assignedAt: new Date().toISOString(),
      isActive: true,
    }

    onUserRolesUpdate([...userRoles, newUserRole])
    setSelectedUser(null)
    setSelectedRole("")
    setSearchQuery("")
    setShowSearch(false)
  }

  const handleRemoveUser = (userId: string) => {
    onUserRolesUpdate(userRoles.filter((ur) => ur.userId !== userId))
  }

  const handleRoleChange = (userId: string, newRole: string) => {
    onUserRolesUpdate(userRoles.map((ur) => (ur.userId === userId ? { ...ur, role: newRole } : ur)))
  }

  return (
    <div>
      {/* Header */}
      <div className="d-flex align-items-center justify-content-between mb-4">
        <div>
          <h6 className="mb-1">Team Members</h6>
          <div className="text-muted small">{userRoles.length} members assigned</div>
        </div>
        <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => setShowSearch(!showSearch)}>
          {showSearch ? "Cancel" : "Add Member"}
        </button>
      </div>

      {/* Add User Form */}
      {showSearch && (
        <div className="card mb-4">
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-6">
                <label className="form-label small">Search User</label>
                <div className="position-relative">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type name or email..."
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                  />
                  {searchResults.length > 0 && (
                    <div className="position-absolute w-100 bg-white border rounded mt-1" style={{ zIndex: 1000 }}>
                      {searchResults.slice(0, 5).map((user) => (
                        <div
                          key={user.id}
                          className="p-2 border-bottom hover-bg-light"
                          style={{ cursor: "pointer" }}
                          onClick={() => handleUserSelect(user)}
                        >
                          <div className="fw-medium">{user.name}</div>
                          <div className="small text-muted">{user.email}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="col-md-4">
                <label className="form-label small">Role</label>
                <select className="form-select" value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
                  <option value="">Select role</option>
                  {SIMPLE_ROLES.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label small">&nbsp;</label>
                <button
                  type="button"
                  className="btn btn-primary w-100"
                  onClick={handleAddUser}
                  disabled={!selectedUser || !selectedRole}
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User List */}
      {userRoles.length > 0 ? (
        <div className="row g-3">
          {userRoles.map((userRole) => {
            const role = getRoleById(userRole.role)
            return (
              <div key={userRole.userId} className="col-md-6">
                <div className="card">
                  <div className="card-body p-3">
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="d-flex align-items-center">
                        <div className="me-3">
                          <div
                            className="rounded-circle bg-light d-flex align-items-center justify-content-center"
                            style={{ width: "40px", height: "40px" }}
                          >
                            <span className="fw-bold text-dark">
                              {userRole.userName
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .toUpperCase()}
                            </span>
                          </div>
                        </div>
                        <div>
                          <div className="fw-medium">{userRole.userName}</div>
                          <div className="small text-muted">{userRole.userEmail}</div>
                        </div>
                      </div>
                      <button
                        type="button"
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => handleRemoveUser(userRole.userId)}
                      >
                        ×
                      </button>
                    </div>
                    <div className="mt-3">
                      <select
                        className="form-select form-select-sm"
                        value={userRole.role}
                        onChange={(e) => handleRoleChange(userRole.userId, e.target.value)}
                      >
                        {SIMPLE_ROLES.map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-4">
          <div className="text-muted">No team members added yet</div>
        </div>
      )}
    </div>
  )
}
