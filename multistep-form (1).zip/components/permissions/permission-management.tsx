"use client"

import { useState } from "react"
import SmartRoleAssignment from "./smart-role-assignment"
import { type UserPermission, canUserAccessStep, getRoleById } from "../../lib/permissions"

interface PermissionManagementProps {
  currentStep: number
  userPermissions: UserPermission[]
  onUserPermissionsUpdate: (permissions: UserPermission[]) => void
  currentUserId?: string
}

export default function PermissionManagement({
  currentStep,
  userPermissions,
  onUserPermissionsUpdate,
  currentUserId = "1",
}: PermissionManagementProps) {
  const [showAddUser, setShowAddUser] = useState(false)
  const [selectedUser, setSelectedUser] = useState<UserPermission | null>(null)

  const handleUserAdd = (newUserPermission: UserPermission) => {
    onUserPermissionsUpdate([...userPermissions, newUserPermission])
    setShowAddUser(false)
  }

  const handleUserRemove = (userId: string) => {
    onUserPermissionsUpdate(userPermissions.filter((up) => up.userId !== userId))
  }

  const handleUserToggle = (userId: string) => {
    onUserPermissionsUpdate(
      userPermissions.map((up) => (up.userId === userId ? { ...up, isActive: !up.isActive } : up)),
    )
  }

  const getStepAccessUsers = (step: number) => {
    return userPermissions.filter((up) => up.isActive && canUserAccessStep(up, step))
  }

  const getPermissionCategoryIcon = (category: string) => {
    switch (category) {
      case "form":
        return "description"
      case "review":
        return "rate_review"
      case "schedule":
        return "schedule"
      case "approve":
        return "how_to_vote"
      case "admin":
        return "admin_panel_settings"
      default:
        return "security"
    }
  }

  const stepNames = ["Initialization", "Request Review", "Committee Scheduling", "Approvals"]

  return (
    <div>
      {/* Header */}
      <div className="d-flex align-items-center justify-content-between mb-4">
        <div>
          <h5 className="mb-1 fw-medium">Permission Management</h5>
          <div className="text-muted small">Manage user access and roles for this process</div>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setShowAddUser(!showAddUser)}>
          <span className="material-icons me-2" style={{ fontSize: "18px" }}>
            {showAddUser ? "close" : "person_add"}
          </span>
          {showAddUser ? "Cancel" : "Add User"}
        </button>
      </div>

      {/* Add User Interface */}
      {showAddUser && (
        <div className="mb-4">
          <SmartRoleAssignment currentStep={currentStep} onUserAdd={handleUserAdd} existingUsers={userPermissions} />
        </div>
      )}

      {/* Current Step Access */}
      <div className="row g-4 mb-4">
        <div className="col-md-8">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-white border-bottom">
              <h6 className="mb-0 fw-medium">
                <span className="material-icons me-2" style={{ fontSize: "20px", verticalAlign: "text-bottom" }}>
                  security
                </span>
                Current Step Access: {stepNames[currentStep]}
              </h6>
            </div>
            <div className="card-body">
              {getStepAccessUsers(currentStep).length > 0 ? (
                <div className="row g-3">
                  {getStepAccessUsers(currentStep).map((userPermission) => (
                    <div key={userPermission.userId} className="col-md-6">
                      <div className="card bg-light border-0">
                        <div className="card-body p-3">
                          <div className="d-flex align-items-center">
                            <div className="me-3">
                              <div
                                className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-medium"
                                style={{ width: "32px", height: "32px", fontSize: "12px" }}
                              >
                                {userPermission.userName
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .toUpperCase()}
                              </div>
                            </div>
                            <div className="flex-grow-1">
                              <div className="fw-medium text-dark small">{userPermission.userName}</div>
                              <div className="d-flex gap-1 mt-1">
                                {userPermission.roles.map((roleId) => {
                                  const role = getRoleById(roleId)
                                  return role ? (
                                    <span key={roleId} className={`badge bg-${role.color} small`}>
                                      {role.name}
                                    </span>
                                  ) : null
                                })}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-3">
                  <span className="material-icons text-muted mb-2" style={{ fontSize: "32px" }}>
                    lock
                  </span>
                  <div className="text-muted">No users have access to this step</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-white border-bottom">
              <h6 className="mb-0 fw-medium">Quick Stats</h6>
            </div>
            <div className="card-body">
              <div className="row g-3 text-center">
                <div className="col-6">
                  <div className="h4 mb-1 text-primary">{userPermissions.filter((up) => up.isActive).length}</div>
                  <div className="small text-muted">Active Users</div>
                </div>
                <div className="col-6">
                  <div className="h4 mb-1 text-success">{getStepAccessUsers(currentStep).length}</div>
                  <div className="small text-muted">Step Access</div>
                </div>
                <div className="col-6">
                  <div className="h4 mb-1 text-info">{new Set(userPermissions.flatMap((up) => up.roles)).size}</div>
                  <div className="small text-muted">Unique Roles</div>
                </div>
                <div className="col-6">
                  <div className="h4 mb-1 text-warning">
                    {stepNames.filter((_, index) => getStepAccessUsers(index).length > 0).length}
                  </div>
                  <div className="small text-muted">Covered Steps</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* All Users */}
      <div className="card border-0 shadow-sm">
        <div className="card-header bg-white border-bottom">
          <h6 className="mb-0 fw-medium">All Team Members ({userPermissions.length})</h6>
        </div>
        <div className="card-body p-0">
          {userPermissions.length > 0 ? (
            <div className="table-responsive">
              <table className="table table-hover mb-0">
                <thead className="table-light">
                  <tr>
                    <th>User</th>
                    <th>Roles</th>
                    <th>Step Access</th>
                    <th>Status</th>
                    <th>Added</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {userPermissions.map((userPermission) => {
                    const accessibleSteps = stepNames.filter((_, index) => canUserAccessStep(userPermission, index))

                    return (
                      <tr key={userPermission.userId} className={!userPermission.isActive ? "table-secondary" : ""}>
                        <td>
                          <div className="d-flex align-items-center">
                            <div className="me-3">
                              <div
                                className="bg-light text-dark rounded-circle d-flex align-items-center justify-content-center fw-medium"
                                style={{ width: "32px", height: "32px", fontSize: "12px" }}
                              >
                                {userPermission.userName
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .toUpperCase()}
                              </div>
                            </div>
                            <div>
                              <div className="fw-medium text-dark">{userPermission.userName}</div>
                              <div className="small text-muted">{userPermission.userEmail}</div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div className="d-flex flex-wrap gap-1">
                            {userPermission.roles.map((roleId) => {
                              const role = getRoleById(roleId)
                              return role ? (
                                <span key={roleId} className={`badge bg-${role.color} small`}>
                                  {role.name}
                                </span>
                              ) : null
                            })}
                          </div>
                        </td>
                        <td>
                          <div className="small">
                            {accessibleSteps.length > 0 ? accessibleSteps.join(", ") : "No access"}
                          </div>
                        </td>
                        <td>
                          <span className={`badge ${userPermission.isActive ? "bg-success" : "bg-secondary"}`}>
                            {userPermission.isActive ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td>
                          <div className="small text-muted">
                            {new Date(userPermission.assignedAt).toLocaleDateString()}
                            <br />
                            by {userPermission.assignedBy}
                          </div>
                        </td>
                        <td>
                          <div className="d-flex gap-1">
                            <button
                              type="button"
                              className={`btn btn-sm ${userPermission.isActive ? "btn-outline-warning" : "btn-outline-success"}`}
                              onClick={() => handleUserToggle(userPermission.userId)}
                              title={userPermission.isActive ? "Deactivate" : "Activate"}
                            >
                              <span className="material-icons" style={{ fontSize: "16px" }}>
                                {userPermission.isActive ? "pause" : "play_arrow"}
                              </span>
                            </button>
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-danger"
                              onClick={() => handleUserRemove(userPermission.userId)}
                              title="Remove user"
                            >
                              <span className="material-icons" style={{ fontSize: "16px" }}>
                                delete
                              </span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-5">
              <span className="material-icons text-muted mb-3" style={{ fontSize: "48px" }}>
                group_add
              </span>
              <h6 className="text-muted">No team members added yet</h6>
              <p className="text-muted mb-0">Add users and assign roles to get started.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
