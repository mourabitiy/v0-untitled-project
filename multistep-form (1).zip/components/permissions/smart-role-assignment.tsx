"use client"

import { useState } from "react"
import { ROLES, type Role, type UserPermission } from "../../lib/permissions"
import { searchUsers, type User } from "../../lib/mock-data"

interface SmartRoleAssignmentProps {
  currentStep: number
  onUserAdd: (userPermission: UserPermission) => void
  existingUsers: UserPermission[]
}

export default function SmartRoleAssignment({ currentStep, onUserAdd, existingUsers }: SmartRoleAssignmentProps) {
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [selectedRoles, setSelectedRoles] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)

  // Get suggested roles based on current step
  const getSuggestedRoles = (step: number): Role[] => {
    switch (step) {
      case 0:
        return ROLES.filter((role) => ["initiator", "process_admin"].includes(role.id))
      case 1:
        return ROLES.filter((role) => ["reviewer", "process_admin"].includes(role.id))
      case 2:
        return ROLES.filter((role) => ["committee", "process_admin"].includes(role.id))
      case 3:
        return ROLES.filter((role) => ["irt_coordinator", "process_admin"].includes(role.id))
      default:
        return ROLES
    }
  }

  const suggestedRoles = getSuggestedRoles(currentStep)
  const existingUserIds = existingUsers.map((u) => u.userId)

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    if (query.length >= 2) {
      const results = searchUsers(query).filter((user) => !existingUserIds.includes(user.id))
      setSearchResults(results)
      setShowSuggestions(results.length > 0)
    } else {
      setSearchResults([])
      setShowSuggestions(false)
    }
  }

  const handleUserSelect = (user: User) => {
    setSelectedUser(user)
    setSearchQuery(user.name)
    setShowSuggestions(false)
    // Auto-suggest roles based on user's team and current step
    const autoSuggestedRoles = getAutoSuggestedRoles(user, currentStep)
    setSelectedRoles(autoSuggestedRoles)
  }

  const getAutoSuggestedRoles = (user: User, step: number): string[] => {
    // Smart role suggestion based on user's team and current step
    const suggestions: string[] = []

    if (user.team === "Security" && step === 1) {
      suggestions.push("reviewer")
    } else if (user.team === "Infrastructure" && step === 2) {
      suggestions.push("committee")
    } else if (user.team === "Development" && step === 3) {
      suggestions.push("irt_coordinator")
    } else if (user.role.toLowerCase().includes("lead") || user.role.toLowerCase().includes("manager")) {
      suggestions.push("process_admin")
    }

    return suggestions
  }

  const handleRoleToggle = (roleId: string) => {
    setSelectedRoles((prev) => (prev.includes(roleId) ? prev.filter((id) => id !== roleId) : [...prev, roleId]))
  }

  const handleAddUser = () => {
    if (!selectedUser || selectedRoles.length === 0) return

    const userPermission: UserPermission = {
      userId: selectedUser.id,
      userName: selectedUser.name,
      userEmail: selectedUser.email,
      roles: selectedRoles,
      assignedBy: "Current User", // Would come from auth
      assignedAt: new Date().toISOString(),
      isActive: true,
    }

    onUserAdd(userPermission)
    setSelectedUser(null)
    setSelectedRoles([])
    setSearchQuery("")
  }

  const getStepName = (step: number): string => {
    const steps = ["Initialization", "Request Review", "Committee Scheduling", "Approvals"]
    return steps[step] || "Unknown"
  }

  return (
    <div className="card border-0 shadow-sm">
      <div className="card-header bg-white border-bottom">
        <div className="d-flex align-items-center justify-content-between">
          <div>
            <h6 className="mb-1 fw-medium">Add Team Member</h6>
            <div className="small text-muted">Current Step: {getStepName(currentStep)}</div>
          </div>
          <span className="badge bg-primary">{existingUsers.length} members</span>
        </div>
      </div>
      <div className="card-body">
        {/* User Search */}
        <div className="mb-4">
          <label className="form-label fw-medium text-dark mb-2">Search User</label>
          <div className="position-relative">
            <div className="input-group">
              <span className="input-group-text bg-white border-end-0">
                <span className="material-icons text-muted" style={{ fontSize: "20px" }}>
                  person_search
                </span>
              </span>
              <input
                type="text"
                className="form-control border-start-0 ps-0"
                placeholder="Search by name, email, or role..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                style={{ boxShadow: "none" }}
              />
            </div>

            {/* Search Results */}
            {showSuggestions && (
              <div
                className="position-absolute w-100 bg-white border rounded-3 shadow-sm mt-1"
                style={{ zIndex: 1000, maxHeight: "200px", overflowY: "auto" }}
              >
                <div className="p-2">
                  {searchResults.map((user) => (
                    <div
                      key={user.id}
                      className="d-flex align-items-center p-2 rounded-2 hover-bg-light"
                      style={{ cursor: "pointer" }}
                      onClick={() => handleUserSelect(user)}
                    >
                      <div className="me-3">
                        <div
                          className="bg-light text-dark rounded-circle d-flex align-items-center justify-content-center fw-medium"
                          style={{ width: "32px", height: "32px", fontSize: "12px" }}
                        >
                          {user.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <div className="fw-medium text-dark">{user.name}</div>
                        <div className="text-muted small">
                          {user.role} • {user.team}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Selected User */}
        {selectedUser && (
          <div className="mb-4">
            <label className="form-label fw-medium text-dark mb-2">Selected User</label>
            <div className="card bg-light border-0">
              <div className="card-body p-3">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div
                      className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-medium"
                      style={{ width: "40px", height: "40px", fontSize: "14px" }}
                    >
                      {selectedUser.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase()}
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <div className="fw-medium text-dark">{selectedUser.name}</div>
                    <div className="text-muted small">{selectedUser.role}</div>
                    <div className="text-muted small">{selectedUser.email}</div>
                  </div>
                  <div className="text-end">
                    <span className="badge bg-secondary">{selectedUser.team}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Role Selection */}
        {selectedUser && (
          <div className="mb-4">
            <label className="form-label fw-medium text-dark mb-2">Assign Roles</label>
            <div className="small text-muted mb-3">
              <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                lightbulb
              </span>
              Suggested roles for {getStepName(currentStep)} step
            </div>

            <div className="row g-3">
              {suggestedRoles.map((role) => (
                <div key={role.id} className="col-md-6">
                  <div
                    className={`card border ${
                      selectedRoles.includes(role.id) ? `border-${role.color} bg-${role.color} bg-opacity-10` : ""
                    }`}
                    style={{ cursor: "pointer" }}
                    onClick={() => handleRoleToggle(role.id)}
                  >
                    <div className="card-body p-3">
                      <div className="d-flex align-items-center">
                        <div className="form-check me-3">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={selectedRoles.includes(role.id)}
                            onChange={() => handleRoleToggle(role.id)}
                          />
                        </div>
                        <div className="flex-grow-1">
                          <div className="fw-medium text-dark">{role.name}</div>
                          <div className="small text-muted">{role.description}</div>
                        </div>
                        <span className={`badge bg-${role.color}`}>
                          {role.stepAccess.length} step{role.stepAccess.length !== 1 ? "s" : ""}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Other Roles */}
            <div className="mt-3">
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                data-bs-toggle="collapse"
                data-bs-target="#otherRoles"
              >
                <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                  expand_more
                </span>
                Show All Roles
              </button>

              <div className="collapse mt-3" id="otherRoles">
                <div className="row g-2">
                  {ROLES.filter((role) => !suggestedRoles.find((sr) => sr.id === role.id)).map((role) => (
                    <div key={role.id} className="col-md-6">
                      <div
                        className={`card border ${
                          selectedRoles.includes(role.id) ? `border-${role.color} bg-${role.color} bg-opacity-10` : ""
                        }`}
                        style={{ cursor: "pointer" }}
                        onClick={() => handleRoleToggle(role.id)}
                      >
                        <div className="card-body p-2">
                          <div className="d-flex align-items-center">
                            <div className="form-check me-2">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                checked={selectedRoles.includes(role.id)}
                                onChange={() => handleRoleToggle(role.id)}
                              />
                            </div>
                            <div className="flex-grow-1">
                              <div className="fw-medium text-dark small">{role.name}</div>
                              <div className="text-muted" style={{ fontSize: "11px" }}>
                                {role.description}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Add Button */}
        {selectedUser && selectedRoles.length > 0 && (
          <div className="d-flex justify-content-end">
            <button type="button" className="btn btn-primary" onClick={handleAddUser}>
              <span className="material-icons me-2" style={{ fontSize: "18px" }}>
                person_add
              </span>
              Add User with {selectedRoles.length} Role{selectedRoles.length !== 1 ? "s" : ""}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
