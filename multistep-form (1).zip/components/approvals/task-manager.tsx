"use client"

import { useState } from "react"

export interface Task {
  id: string
  type: "pre" | "post"
  name: string
  description: string
  dueDate: string
}

interface TaskManagerProps {
  userId: string
  userName: string
  tasks: Task[]
  onTasksUpdate: (userId: string, tasks: Task[]) => void
}

export default function TaskManager({ userId, userName, tasks, onTasksUpdate }: TaskManagerProps) {
  const [showAddTask, setShowAddTask] = useState(false)
  const [newTask, setNewTask] = useState<Omit<Task, "id">>({
    type: "pre",
    name: "",
    description: "",
    dueDate: "",
  })

  const handleAddTask = () => {
    if (!newTask.name.trim() || !newTask.description.trim() || !newTask.dueDate) return

    const task: Task = {
      id: crypto.randomUUID(),
      ...newTask,
    }

    onTasksUpdate(userId, [...tasks, task])
    setNewTask({
      type: "pre",
      name: "",
      description: "",
      dueDate: "",
    })
    setShowAddTask(false)
  }

  const handleRemoveTask = (taskId: string) => {
    onTasksUpdate(
      userId,
      tasks.filter((t) => t.id !== taskId),
    )
  }

  const handleTaskUpdate = (taskId: string, field: keyof Task, value: string) => {
    onTasksUpdate(
      userId,
      tasks.map((t) => (t.id === taskId ? { ...t, [field]: value } : t)),
    )
  }

  return (
    <div className="mt-3">
      <div className="d-flex align-items-center justify-content-between mb-3">
        <div>
          <h6 className="mb-0">Tasks for {userName}</h6>
          <div className="text-muted small">
            {tasks.length} task{tasks.length !== 1 ? "s" : ""}
          </div>
        </div>
        <button type="button" className="btn btn-sm btn-outline-primary" onClick={() => setShowAddTask(!showAddTask)}>
          <span className="material-icons me-1" style={{ fontSize: "16px" }}>
            {showAddTask ? "close" : "add_task"}
          </span>
          {showAddTask ? "Cancel" : "Add Task"}
        </button>
      </div>

      {/* Add Task Form */}
      {showAddTask && (
        <div className="card mb-3">
          <div className="card-body p-3">
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label small">Type</label>
                <select
                  className="form-select form-select-sm"
                  value={newTask.type}
                  onChange={(e) => setNewTask({ ...newTask, type: e.target.value as "pre" | "post" })}
                >
                  <option value="pre">Pre-condition</option>
                  <option value="post">Post-condition</option>
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label small">Task Name</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  placeholder="Enter task name"
                  value={newTask.name}
                  onChange={(e) => setNewTask({ ...newTask, name: e.target.value })}
                />
              </div>
              <div className="col-md-3">
                <label className="form-label small">Due Date</label>
                <input
                  type="date"
                  className="form-control form-control-sm"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                />
              </div>
              <div className="col-md-2">
                <label className="form-label small">&nbsp;</label>
                <button type="button" className="btn btn-sm btn-primary w-100" onClick={handleAddTask}>
                  Add
                </button>
              </div>
              <div className="col-12">
                <label className="form-label small">Description</label>
                <textarea
                  className="form-control form-control-sm"
                  rows={2}
                  placeholder="Enter task description"
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tasks List */}
      {tasks.length > 0 && (
        <div className="d-flex flex-column gap-2">
          {tasks.map((task) => (
            <div key={task.id} className="card border-start border-3 border-primary">
              <div className="card-body p-3">
                <div className="row g-2 align-items-start">
                  <div className="col-md-2">
                    <select
                      className="form-select form-select-sm"
                      value={task.type}
                      onChange={(e) => handleTaskUpdate(task.id, "type", e.target.value)}
                    >
                      <option value="pre">Pre-condition</option>
                      <option value="post">Post-condition</option>
                    </select>
                  </div>
                  <div className="col-md-4">
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={task.name}
                      onChange={(e) => handleTaskUpdate(task.id, "name", e.target.value)}
                    />
                  </div>
                  <div className="col-md-3">
                    <input
                      type="date"
                      className="form-control form-control-sm"
                      value={task.dueDate}
                      onChange={(e) => handleTaskUpdate(task.id, "dueDate", e.target.value)}
                    />
                  </div>
                  <div className="col-md-2">
                    <div className="d-flex gap-1">
                      <span
                        className={`badge ${task.type === "pre" ? "bg-warning" : "bg-info"} small`}
                        style={{ fontSize: "10px" }}
                      >
                        {task.type === "pre" ? "PRE" : "POST"}
                      </span>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-danger"
                        style={{ padding: "2px 6px" }}
                        onClick={() => handleRemoveTask(task.id)}
                      >
                        <span className="material-icons" style={{ fontSize: "14px" }}>
                          delete
                        </span>
                      </button>
                    </div>
                  </div>
                  <div className="col-12">
                    <textarea
                      className="form-control form-control-sm"
                      rows={2}
                      value={task.description}
                      onChange={(e) => handleTaskUpdate(task.id, "description", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
