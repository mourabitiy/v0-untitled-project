interface FormTimelineProps {
  steps: string[]
  currentStep: number
}

export default function FormTimeline({ steps, currentStep }: FormTimelineProps) {
  return (
    <div className="mb-5 position-relative">
      <div className="progress" style={{ height: "2px" }}>
        <div
          className="progress-bar"
          role="progressbar"
          style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
          aria-valuenow={(currentStep / (steps.length - 1)) * 100}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
      </div>
      <ol className="d-flex justify-content-between position-relative" style={{ marginTop: "-14px" }}>
        {steps.map((step, index) => (
          <li key={step} className="d-flex flex-column align-items-center position-relative">
            <div
              className={`d-flex align-items-center justify-content-center rounded-circle ${
                index < currentStep
                  ? "bg-primary border-primary text-white"
                  : index === currentStep
                    ? "border border-primary text-primary bg-white"
                    : "border border-gray-300 text-muted bg-white"
              }`}
              style={{ width: "30px", height: "30px", zIndex: 1 }}
            >
              {index < currentStep ? (
                <span className="material-icons" style={{ fontSize: "16px" }}>
                  check
                </span>
              ) : (
                <span className="small">{index + 1}</span>
              )}
            </div>
            <span
              className={`position-absolute text-center small ${index <= currentStep ? "text-dark" : "text-muted"}`}
              style={{ width: "100px", top: "30px", left: "-35px" }}
            >
              {step}
            </span>
          </li>
        ))}
      </ol>
    </div>
  )
}
