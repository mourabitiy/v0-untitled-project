"use client"

import type React from "react"

import { useRef } from "react"
import { isExcelFile } from "./file-types"

interface UploadAreaProps {
  onFilesSelected: (files: File[]) => void
  isDragging: boolean
  setIsDragging: (isDragging: boolean) => void
}

export default function UploadArea({ onFilesSelected, isDragging, setIsDragging }: UploadAreaProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return

    const selectedFiles = Array.from(e.target.files)
    const validFiles = selectedFiles.filter((file) => isExcelFile(file))

    if (validFiles.length !== selectedFiles.length) {
      alert("Only Excel files (.xlsx, .xls) and CSV files (.csv) are allowed")
    }

    if (validFiles.length > 0) {
      onFilesSelected(validFiles)
    }

    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files?.length) {
      const droppedFiles = Array.from(e.dataTransfer.files)
      const validFiles = droppedFiles.filter((file) => isExcelFile(file))

      if (validFiles.length !== droppedFiles.length) {
        alert("Only Excel files (.xlsx, .xls) and CSV files (.csv) are allowed")
      }

      if (validFiles.length > 0) {
        onFilesSelected(validFiles)
      }
    }
  }

  return (
    <div
      className={`upload-area p-4 mb-4 text-center border-2 rounded-3 ${
        isDragging ? "border-primary bg-light border-dashed" : "border-dashed border-secondary"
      }`}
      onDragOver={(e) => {
        e.preventDefault()
        setIsDragging(true)
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
      style={{ cursor: "pointer" }}
    >
      <input
        ref={fileInputRef}
        type="file"
        className="d-none"
        onChange={handleFileChange}
        multiple
        accept=".xlsx,.xls,.csv"
      />
      <span className="material-icons text-primary" style={{ fontSize: "40px" }}>
        cloud_upload
      </span>
      <h5>Drag & Drop Excel Files Here</h5>
      <p className="text-muted mb-1">or click to browse files</p>
      <div className="d-flex justify-content-center align-items-center gap-2 mb-2">
        <span className="badge bg-success">.xlsx</span>
        <span className="badge bg-success">.xls</span>
        <span className="badge bg-success">.csv</span>
      </div>
      <p className="small text-muted">Maximum file size: 10MB</p>
    </div>
  )
}
