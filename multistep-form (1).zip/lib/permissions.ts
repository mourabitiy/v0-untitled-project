export interface Permission {
  id: string
  name: string
  description: string
  category: "form" | "review" | "schedule" | "approve" | "admin"
}

export interface Role {
  id: string
  name: string
  description: string
  color: string
  permissions: string[]
  stepAccess: number[]
}

export interface UserPermission {
  userId: string
  userName: string
  userEmail: string
  roles: string[]
  assignedBy: string
  assignedAt: string
  isActive: boolean
}

// Define all available permissions
export const PERMISSIONS: Permission[] = [
  // Form permissions
  { id: "form.create", name: "Create Form", description: "Can create new forms", category: "form" },
  { id: "form.edit", name: "Edit Form", description: "Can edit form data", category: "form" },
  { id: "form.view", name: "View Form", description: "Can view form data", category: "form" },
  { id: "form.delete", name: "Delete Form", description: "Can delete forms", category: "form" },

  // Review permissions
  { id: "review.approve", name: "Approve Review", description: "Can approve form submissions", category: "review" },
  { id: "review.reject", name: "Reject Review", description: "Can reject form submissions", category: "review" },
  { id: "review.comment", name: "Add Comments", description: "Can add review comments", category: "review" },

  // Schedule permissions
  {
    id: "schedule.create",
    name: "Create Schedule",
    description: "Can create committee schedules",
    category: "schedule",
  },
  { id: "schedule.edit", name: "Edit Schedule", description: "Can edit schedules", category: "schedule" },
  { id: "schedule.view", name: "View Schedule", description: "Can view schedules", category: "schedule" },

  // Approval permissions
  { id: "approve.manage", name: "Manage Approvals", description: "Can manage approval process", category: "approve" },
  { id: "approve.assign", name: "Assign Approvers", description: "Can assign team members", category: "approve" },
  { id: "approve.respond", name: "Respond to Approval", description: "Can approve/reject", category: "approve" },

  // Admin permissions
  { id: "admin.users", name: "Manage Users", description: "Can manage user permissions", category: "admin" },
  { id: "admin.roles", name: "Manage Roles", description: "Can create and edit roles", category: "admin" },
  { id: "admin.system", name: "System Admin", description: "Full system access", category: "admin" },
]

// Define predefined roles
export const ROLES: Role[] = [
  {
    id: "initiator",
    name: "Form Initiator",
    description: "Can create and edit forms",
    color: "primary",
    permissions: ["form.create", "form.edit", "form.view"],
    stepAccess: [0],
  },
  {
    id: "reviewer",
    name: "Reviewer",
    description: "Can review and approve/reject submissions",
    color: "warning",
    permissions: ["form.view", "review.approve", "review.reject", "review.comment"],
    stepAccess: [1],
  },
  {
    id: "committee",
    name: "Committee Member",
    description: "Can manage committee scheduling",
    color: "info",
    permissions: ["form.view", "schedule.create", "schedule.edit", "schedule.view"],
    stepAccess: [2],
  },
  {
    id: "irt_coordinator",
    name: "IRT Coordinator",
    description: "Can manage final approval process",
    color: "success",
    permissions: ["form.view", "approve.manage", "approve.assign", "approve.respond"],
    stepAccess: [3],
  },
  {
    id: "process_admin",
    name: "Process Administrator",
    description: "Can manage the entire process and permissions",
    color: "danger",
    permissions: [
      "form.create",
      "form.edit",
      "form.view",
      "form.delete",
      "review.approve",
      "review.reject",
      "review.comment",
      "schedule.create",
      "schedule.edit",
      "schedule.view",
      "approve.manage",
      "approve.assign",
      "approve.respond",
      "admin.users",
      "admin.roles",
      "admin.system",
    ],
    stepAccess: [0, 1, 2, 3],
  },
]

// Helper functions
export function getRoleById(roleId: string): Role | undefined {
  return ROLES.find((role) => role.id === roleId)
}

export function getPermissionById(permissionId: string): Permission | undefined {
  return PERMISSIONS.find((permission) => permission.id === permissionId)
}

export function getUserPermissions(userPermission: UserPermission): Permission[] {
  const allPermissions: Permission[] = []
  userPermission.roles.forEach((roleId) => {
    const role = getRoleById(roleId)
    if (role) {
      role.permissions.forEach((permissionId) => {
        const permission = getPermissionById(permissionId)
        if (permission && !allPermissions.find((p) => p.id === permission.id)) {
          allPermissions.push(permission)
        }
      })
    }
  })
  return allPermissions
}

export function canUserAccessStep(userPermission: UserPermission, step: number): boolean {
  return userPermission.roles.some((roleId) => {
    const role = getRoleById(roleId)
    return role?.stepAccess.includes(step)
  })
}

export function hasPermission(userPermission: UserPermission, permissionId: string): boolean {
  const permissions = getUserPermissions(userPermission)
  return permissions.some((p) => p.id === permissionId)
}
