export interface SimpleRole {
  id: string
  name: string
  description: string
  color: string
}

export interface UserRole {
  userId: string
  userName: string
  userEmail: string
  role: string
  assignedBy: string
  assignedAt: string
  isActive: boolean
}

// Simple roles without complex permissions
export const SIMPLE_ROLES: SimpleRole[] = [
  {
    id: "initiator",
    name: "Initiator",
    description: "Can create and submit forms",
    color: "primary",
  },
  {
    id: "reviewer",
    name: "Reviewer",
    description: "Can review and approve submissions",
    color: "warning",
  },
  {
    id: "committee",
    name: "Committee Member",
    description: "Can manage scheduling and meetings",
    color: "info",
  },
  {
    id: "approver",
    name: "Approver",
    description: "Can provide final approval",
    color: "success",
  },
  {
    id: "admin",
    name: "Administrator",
    description: "Can manage the entire process",
    color: "danger",
  },
]

export function getRoleById(roleId: string): SimpleRole | undefined {
  return SIMPLE_ROLES.find((role) => role.id === roleId)
}
