"use server"

import type { FormData } from "./types"
import { revalidatePath } from "next/cache"

// In a real application, this would connect to a database
const formsStore = new Map<string, FormData>()

export async function saveFormData(formData: FormData) {
  try {
    // In a real application, you would save to a database
    formsStore.set(formData.formId, {
      ...formData,
      lastUpdated: new Date().toISOString(),
    })

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("Error saving form data:", error)
    return { success: false, error: "Failed to save form data" }
  }
}

export async function getFormData(formId: string): Promise<FormData | null> {
  try {
    // In a real application, you would fetch from a database
    const data = formsStore.get(formId)

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    return data || null
  } catch (error) {
    console.error("Error fetching form data:", error)
    return null
  }
}

export async function submitFormStep(formData: FormData, stepName: string) {
  try {
    // In a real application, you might have different logic per step
    // or notify different teams based on the step

    formsStore.set(formData.formId, {
      ...formData,
      lastUpdated: new Date().toISOString(),
    })

    // Simulate sending notifications to relevant teams
    console.log(`Step ${stepName} completed for form ${formData.formId}`)

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 800))

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error(`Error submitting form step ${stepName}:`, error)
    return { success: false, error: `Failed to submit ${stepName}` }
  }
}
