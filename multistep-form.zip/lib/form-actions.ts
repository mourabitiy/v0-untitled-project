"use server"

import type { FormData, FormStatus, RejectionInfo } from "./types"
import { revalidatePath } from "next/cache"

// In a real application, this would connect to a database
const formsStore = new Map<string, FormData>()

// Centralized function to determine next step based on status
function getStepFromStatus(status: FormStatus): number {
  switch (status) {
    case "draft":
    case "rejected":
      return 0 // Initialization step
    case "submitted":
    case "under_review":
      return 1 // Request Review step
    case "approved_for_scheduling":
    case "scheduled":
      return 2 // Committee Scheduling step
    case "final_approval":
    case "completed":
      return 3 // Approval step
    default:
      return 0
  }
}

// Centralized function to determine next status based on current step and action
function getNextStatus(currentStatus: FormStatus, stepName: string, action: "complete" | "reject"): FormStatus {
  if (action === "reject") {
    return "rejected"
  }

  switch (stepName) {
    case "Initialization":
      return "submitted"
    case "Request Review":
      return "approved_for_scheduling"
    case "Committee Scheduling":
      return "final_approval"
    case "Approvals":
      return "completed"
    default:
      return currentStatus
  }
}

export async function saveFormData(formData: FormData) {
  try {
    const processedFormData = {
      ...formData,
      lastUpdated: new Date().toISOString(),
    }

    formsStore.set(formData.formId, processedFormData)
    await new Promise((resolve) => setTimeout(resolve, 500))

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("Error saving form data:", error)
    return { success: false, error: "Failed to save form data" }
  }
}

export async function getFormData(formId: string): Promise<FormData | null> {
  try {
    const data = formsStore.get(formId)
    await new Promise((resolve) => setTimeout(resolve, 500))
    return data || null
  } catch (error) {
    console.error("Error fetching form data:", error)
    return null
  }
}

// Centralized API function for all form updates
export async function updateFormStep(
  formData: FormData,
  stepName: string,
  stepData: any,
  action: "complete" | "reject" = "complete",
) {
  try {
    const currentStatus = formData.status
    const nextStatus = getNextStatus(currentStatus, stepName, action)
    const nextStep = getStepFromStatus(nextStatus)

    let rejectionInfo: RejectionInfo | undefined = undefined

    // Handle rejection
    if (action === "reject") {
      rejectionInfo = {
        rejectedBy: stepData.reviewerName || "Unknown Reviewer",
        rejectedAt: new Date().toISOString(),
        reason: stepData.rejectionReason || "No reason provided",
        step: stepName,
      }
    }

    const updatedFormData: FormData = {
      ...formData,
      [stepName.toLowerCase().replace(/\s+/g, "")]: stepData,
      status: nextStatus,
      currentStep: nextStep,
      lastUpdated: new Date().toISOString(),
      lastUpdatedBy: stepData.reviewerName || stepData.initiatorName || "Current User",
      ...(rejectionInfo && { rejectionInfo }),
    }

    // Store the updated form data
    formsStore.set(formData.formId, updatedFormData)

    // Simulate API processing time
    await new Promise((resolve) => setTimeout(resolve, 800))

    // Log the status change for debugging
    console.log(`Form ${formData.formId}: ${currentStatus} -> ${nextStatus} (Step: ${stepName}, Action: ${action})`)

    revalidatePath("/")
    return {
      success: true,
      formData: updatedFormData,
      message:
        action === "reject"
          ? `Project rejected and returned to initialization step`
          : `${stepName} completed successfully`,
    }
  } catch (error) {
    console.error(`Error updating form step ${stepName}:`, error)
    return {
      success: false,
      error: `Failed to update ${stepName}`,
      formData: formData,
    }
  }
}

// Legacy function for backward compatibility
export async function submitFormStep(formData: FormData, stepName: string) {
  return updateFormStep(formData, stepName, {}, "complete")
}
