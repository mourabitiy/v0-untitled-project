export interface FileObject {
  id: string
  file: File
  type: string
  progress: number
  error?: string
  uploaded: boolean
}

export type FormStatus =
  | "draft"
  | "submitted"
  | "under_review"
  | "rejected"
  | "approved_for_scheduling"
  | "scheduled"
  | "final_approval"
  | "completed"

export interface RejectionInfo {
  rejectedBy: string
  rejectedAt: string
  reason: string
  step: string
}

export interface FormData {
  initialization: any | null
  requestReview: any | null
  committeeScheduling: any | null
  approval: any | null
  status: FormStatus
  currentStep: number
  formId: string
  lastUpdated: string
  lastUpdatedBy: string
  rejectionInfo?: RejectionInfo
}
