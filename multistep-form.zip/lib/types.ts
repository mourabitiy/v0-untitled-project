export interface FormData {
  initialization: any | null
  requestReview: any | null
  committeeScheduling: any | null
  approval: any | null
  currentStep: number
  formId: string
  lastUpdated: string
  lastUpdatedBy: string
}
