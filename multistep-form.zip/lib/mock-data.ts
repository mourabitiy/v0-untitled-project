export interface User {
  id: string
  name: string
  email: string
  team: string
  role: string
  avatar?: string
}

export interface Team {
  id: string
  name: string
  members: User[]
}

// Mock users and teams data
export const mockUsers: User[] = [
  // Security Team
  { id: "1", name: "Alice Johnson", email: "alice.johnson@company.com", team: "Security", role: "Security Lead" },
  { id: "2", name: "Bob Smith", email: "bob.smith@company.com", team: "Security", role: "Security Analyst" },
  { id: "3", name: "Carol Davis", email: "carol.davis@company.com", team: "Security", role: "Security Engineer" },

  // Infrastructure Team
  {
    id: "4",
    name: "David Wilson",
    email: "david.wilson@company.com",
    team: "Infrastructure",
    role: "Infrastructure Lead",
  },
  { id: "5", name: "Emma Brown", email: "emma.brown@company.com", team: "Infrastructure", role: "DevOps Engineer" },
  { id: "6", name: "Frank Miller", email: "frank.miller@company.com", team: "Infrastructure", role: "System Admin" },

  // Development Team
  { id: "7", name: "Grace Lee", email: "grace.lee@company.com", team: "Development", role: "Tech Lead" },
  { id: "8", name: "Henry Taylor", email: "henry.taylor@company.com", team: "Development", role: "Senior Developer" },
  { id: "9", name: "Iris Chen", email: "iris.chen@company.com", team: "Development", role: "Full Stack Developer" },

  // Quality Assurance Team
  { id: "10", name: "Jack Anderson", email: "jack.anderson@company.com", team: "QA", role: "QA Lead" },
  { id: "11", name: "Kate Wilson", email: "kate.wilson@company.com", team: "QA", role: "QA Engineer" },
  { id: "12", name: "Liam Garcia", email: "liam.garcia@company.com", team: "QA", role: "Test Automation Engineer" },
]

export const mockTeams: Team[] = [
  {
    id: "security",
    name: "Security",
    members: mockUsers.filter((user) => user.team === "Security"),
  },
  {
    id: "infrastructure",
    name: "Infrastructure",
    members: mockUsers.filter((user) => user.team === "Infrastructure"),
  },
  {
    id: "development",
    name: "Development",
    members: mockUsers.filter((user) => user.team === "Development"),
  },
  {
    id: "qa",
    name: "QA",
    members: mockUsers.filter((user) => user.team === "QA"),
  },
]

export interface UserApproval {
  userId: string
  userName: string
  userEmail: string
  team: string
  role: string
  status: "pending" | "approved" | "rejected"
  comment: string
  approvedAt?: string
  canEdit: boolean // Whether current user can edit this approval
}

// Mock function to search users
export function searchUsers(query: string): User[] {
  if (!query || query.length < 2) return []

  const lowerQuery = query.toLowerCase()
  return mockUsers.filter(
    (user) =>
      user.name.toLowerCase().includes(lowerQuery) ||
      user.email.toLowerCase().includes(lowerQuery) ||
      user.role.toLowerCase().includes(lowerQuery),
  )
}

// Mock function to get team members by expert
export function getTeamByExpert(expertId: string): User[] {
  const expert = mockUsers.find((user) => user.id === expertId)
  if (!expert) return []

  return mockUsers.filter((user) => user.team === expert.team)
}
