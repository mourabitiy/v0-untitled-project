"use client"

import { useState } from "react"
import type { UserApproval } from "../../lib/mock-data"

interface ProfessionalApprovalInterfaceProps {
  approvals: UserApproval[]
  onApprovalUpdate: (userId: string, status: "approved" | "rejected", comment: string) => void
  onUserRemove: (userId: string) => void
  currentUserId?: string
}

export default function ProfessionalApprovalInterface({
  approvals,
  onApprovalUpdate,
  onUserRemove,
  currentUserId = "1",
}: ProfessionalApprovalInterfaceProps) {
  const [editingComments, setEditingComments] = useState<{ [key: string]: string }>({})

  const handleStatusChange = (userId: string, status: "approved" | "rejected") => {
    const comment = editingComments[userId] || ""
    onApprovalUpdate(userId, status, comment)
    setEditingComments((prev) => ({ ...prev, [userId]: "" }))
  }

  const handleCommentChange = (userId: string, comment: string) => {
    setEditingComments((prev) => ({ ...prev, [userId]: comment }))
  }

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case "approved":
        return {
          icon: "check_circle",
          text: "Approved",
          class: "text-success",
          bgClass: "bg-success bg-opacity-10",
        }
      case "rejected":
        return {
          icon: "cancel",
          text: "Rejected",
          class: "text-danger",
          bgClass: "bg-danger bg-opacity-10",
        }
      default:
        return {
          icon: "schedule",
          text: "Pending",
          class: "text-warning",
          bgClass: "bg-warning bg-opacity-10",
        }
    }
  }

  if (approvals.length === 0) {
    return (
      <div className="text-center py-5">
        <div className="mb-4">
          <span className="material-icons text-muted" style={{ fontSize: "64px" }}>
            group
          </span>
        </div>
        <h5 className="text-muted mb-2">No team members added yet</h5>
        <p className="text-muted mb-0">Search and add team members to begin the approval process.</p>
      </div>
    )
  }

  const stats = {
    total: approvals.length,
    approved: approvals.filter((a) => a.status === "approved").length,
    rejected: approvals.filter((a) => a.status === "rejected").length,
    pending: approvals.filter((a) => a.status === "pending").length,
  }

  return (
    <div>
      {/* Stats Header */}
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <div className="card border-0 bg-light">
            <div className="card-body text-center py-3">
              <div className="h4 mb-1 text-dark">{stats.total}</div>
              <div className="text-muted small">Total Members</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 bg-success bg-opacity-10">
            <div className="card-body text-center py-3">
              <div className="h4 mb-1 text-success">{stats.approved}</div>
              <div className="text-muted small">Approved</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 bg-danger bg-opacity-10">
            <div className="card-body text-center py-3">
              <div className="h4 mb-1 text-danger">{stats.rejected}</div>
              <div className="text-muted small">Rejected</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 bg-warning bg-opacity-10">
            <div className="card-body text-center py-3">
              <div className="h4 mb-1 text-warning">{stats.pending}</div>
              <div className="text-muted small">Pending</div>
            </div>
          </div>
        </div>
      </div>

      {/* Approval List */}
      <div className="card border-0 shadow-sm">
        <div className="card-header bg-white border-bottom">
          <div className="d-flex align-items-center justify-content-between">
            <h6 className="mb-0 fw-medium">Team Member Approvals</h6>
            <div className="text-muted small">
              {stats.approved} of {stats.total} approved
            </div>
          </div>
        </div>
        <div className="card-body p-0">
          {approvals.map((approval, index) => {
            const isCurrentUser = approval.userId === currentUserId
            const canEdit = isCurrentUser && approval.status === "pending"
            const currentComment = editingComments[approval.userId] ?? approval.comment
            const statusDisplay = getStatusDisplay(approval.status)

            return (
              <div
                key={approval.userId}
                className={`p-4 ${index > 0 ? "border-top" : ""} ${isCurrentUser ? "bg-primary bg-opacity-5" : ""}`}
              >
                <div className="row align-items-start">
                  {/* User Information */}
                  <div className="col-lg-4">
                    <div className="d-flex align-items-center">
                      <div className="me-3">
                        <div
                          className="bg-light text-dark rounded-circle d-flex align-items-center justify-content-center fw-medium"
                          style={{ width: "48px", height: "48px", fontSize: "16px" }}
                        >
                          {approval.userName
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <div className="d-flex align-items-center mb-1">
                          <span className="fw-medium text-dark">{approval.userName}</span>
                          {isCurrentUser && <span className="badge bg-primary ms-2 small">You</span>}
                        </div>
                        <div className="text-muted small mb-1">{approval.role}</div>
                        <div className="text-muted small">{approval.team} Team</div>
                      </div>
                    </div>
                  </div>

                  {/* Status */}
                  <div className="col-lg-2">
                    <div className={`d-inline-flex align-items-center px-3 py-2 rounded-pill ${statusDisplay.bgClass}`}>
                      <span className={`material-icons me-2 ${statusDisplay.class}`} style={{ fontSize: "18px" }}>
                        {statusDisplay.icon}
                      </span>
                      <span className={`small fw-medium ${statusDisplay.class}`}>{statusDisplay.text}</span>
                    </div>
                    {approval.approvedAt && (
                      <div className="text-muted small mt-2">{new Date(approval.approvedAt).toLocaleDateString()}</div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="col-lg-3">
                    {canEdit ? (
                      <div className="d-flex gap-2">
                        <button
                          type="button"
                          className="btn btn-success btn-sm"
                          onClick={() => handleStatusChange(approval.userId, "approved")}
                        >
                          <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                            check
                          </span>
                          Approve
                        </button>
                        <button
                          type="button"
                          className="btn btn-outline-danger btn-sm"
                          onClick={() => handleStatusChange(approval.userId, "rejected")}
                        >
                          <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                            close
                          </span>
                          Reject
                        </button>
                      </div>
                    ) : (
                      <div className="text-muted small">
                        {approval.status === "pending" ? "Awaiting response" : "Decision submitted"}
                      </div>
                    )}
                  </div>

                  {/* Actions Menu */}
                  <div className="col-lg-3 text-end">
                    {approval.status === "pending" && (
                      <button
                        type="button"
                        className="btn btn-outline-secondary btn-sm"
                        onClick={() => onUserRemove(approval.userId)}
                        title="Remove member"
                      >
                        <span className="material-icons" style={{ fontSize: "16px" }}>
                          person_remove
                        </span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Comments Section */}
                <div className="row mt-3">
                  <div className="col-12">
                    <label className="form-label small text-muted mb-2">{canEdit ? "Your Comment" : "Comment"}</label>
                    {canEdit ? (
                      <textarea
                        className="form-control"
                        rows={3}
                        placeholder="Add your comments about this approval..."
                        value={currentComment}
                        onChange={(e) => handleCommentChange(approval.userId, e.target.value)}
                        style={{ resize: "none" }}
                      />
                    ) : (
                      <div className="bg-light rounded p-3">
                        {approval.comment ? (
                          <div className="text-dark">{approval.comment}</div>
                        ) : (
                          <div className="text-muted fst-italic">No comment provided</div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
