"use client"

import { useState } from "react"
import type { UserApproval } from "../../lib/mock-data"

interface SimpleApprovalInterfaceProps {
  approvals: UserApproval[]
  onApprovalUpdate: (userId: string, status: "approved" | "rejected", comment: string) => void
  onUserRemove: (userId: string) => void
  currentUserId?: string
}

export default function SimpleApprovalInterface({
  approvals,
  onApprovalUpdate,
  onUserRemove,
  currentUserId = "1",
}: SimpleApprovalInterfaceProps) {
  const [editingComments, setEditingComments] = useState<{ [key: string]: string }>({})

  const handleStatusChange = (userId: string, status: "approved" | "rejected") => {
    const comment = editingComments[userId] || ""
    onApprovalUpdate(userId, status, comment)
    setEditingComments((prev) => ({ ...prev, [userId]: "" }))
  }

  const handleCommentChange = (userId: string, comment: string) => {
    setEditingComments((prev) => ({ ...prev, [userId]: comment }))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "success"
      case "rejected":
        return "danger"
      default:
        return "warning"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return "check_circle"
      case "rejected":
        return "cancel"
      default:
        return "schedule"
    }
  }

  if (approvals.length === 0) {
    return (
      <div className="card">
        <div className="card-body text-center py-5">
          <span className="material-icons text-muted mb-3" style={{ fontSize: "48px" }}>
            person_add
          </span>
          <h5 className="text-muted">No IRT Members Added</h5>
          <p className="text-muted">Search and add users to get their approval.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="card-header bg-primary text-white">
        <div className="d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center">
            <span className="material-icons me-2">how_to_vote</span>
            <h5 className="mb-0">IRT Approvals ({approvals.length} members)</h5>
          </div>
          <div className="text-end">
            <span className="badge bg-light text-dark">
              {approvals.filter((a) => a.status === "approved").length} of {approvals.length} approved
            </span>
          </div>
        </div>
      </div>
      <div className="card-body p-0">
        {approvals.map((approval, index) => {
          const isCurrentUser = approval.userId === currentUserId
          const canEdit = isCurrentUser && approval.status === "pending"
          const currentComment = editingComments[approval.userId] ?? approval.comment

          return (
            <div key={approval.userId} className={`p-3 ${index > 0 ? "border-top" : ""}`}>
              <div className="row align-items-start">
                {/* User Info */}
                <div className="col-md-3">
                  <div className="d-flex align-items-center">
                    <div className="me-3">
                      <div
                        className="bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center"
                        style={{ width: "40px", height: "40px", fontSize: "14px" }}
                      >
                        {approval.userName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()}
                      </div>
                    </div>
                    <div>
                      <div className="fw-bold">
                        {approval.userName}
                        {isCurrentUser && <span className="badge bg-info ms-2">You</span>}
                      </div>
                      <div className="small text-muted">{approval.role}</div>
                      <div className="small text-muted">{approval.team}</div>
                    </div>
                  </div>
                </div>

                {/* Status */}
                <div className="col-md-2">
                  <div className="d-flex align-items-center">
                    <span className={`material-icons text-${getStatusColor(approval.status)} me-2`}>
                      {getStatusIcon(approval.status)}
                    </span>
                    <span className={`badge bg-${getStatusColor(approval.status)}`}>
                      {approval.status === "pending"
                        ? "Pending"
                        : approval.status === "approved"
                          ? "Approved"
                          : "Rejected"}
                    </span>
                  </div>
                  {approval.approvedAt && (
                    <div className="small text-muted mt-1">{new Date(approval.approvedAt).toLocaleDateString()}</div>
                  )}
                </div>

                {/* Actions */}
                <div className="col-md-2">
                  {canEdit ? (
                    <div className="d-flex gap-2">
                      <button
                        type="button"
                        className="btn btn-sm btn-success"
                        onClick={() => handleStatusChange(approval.userId, "approved")}
                        title="Approve"
                      >
                        <span className="material-icons" style={{ fontSize: "16px" }}>
                          check
                        </span>
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        onClick={() => handleStatusChange(approval.userId, "rejected")}
                        title="Reject"
                      >
                        <span className="material-icons" style={{ fontSize: "16px" }}>
                          close
                        </span>
                      </button>
                    </div>
                  ) : (
                    <span className="text-muted small">
                      {approval.status === "pending" ? "Awaiting response" : "Decision made"}
                    </span>
                  )}
                </div>

                {/* Comments */}
                <div className="col-md-4">
                  {canEdit ? (
                    <div>
                      <label className="form-label small">Your Comment</label>
                      <textarea
                        className="form-control form-control-sm"
                        rows={2}
                        placeholder="Add your comments..."
                        value={currentComment}
                        onChange={(e) => handleCommentChange(approval.userId, e.target.value)}
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="form-label small text-muted">Comment</label>
                      <div className="small">
                        {approval.comment || <span className="text-muted">No comments provided</span>}
                      </div>
                    </div>
                  )}
                </div>

                {/* Remove Button */}
                <div className="col-md-1">
                  {approval.status === "pending" && (
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => onUserRemove(approval.userId)}
                      title="Remove user"
                    >
                      <span className="material-icons" style={{ fontSize: "16px" }}>
                        person_remove
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Summary Footer */}
      <div className="card-footer bg-light">
        <div className="row text-center">
          <div className="col-3">
            <div className="h6 mb-0 text-success">{approvals.filter((a) => a.status === "approved").length}</div>
            <div className="small text-muted">Approved</div>
          </div>
          <div className="col-3">
            <div className="h6 mb-0 text-danger">{approvals.filter((a) => a.status === "rejected").length}</div>
            <div className="small text-muted">Rejected</div>
          </div>
          <div className="col-3">
            <div className="h6 mb-0 text-warning">{approvals.filter((a) => a.status === "pending").length}</div>
            <div className="small text-muted">Pending</div>
          </div>
          <div className="col-3">
            <div className="h6 mb-0 text-primary">
              {approvals.length > 0
                ? Math.round((approvals.filter((a) => a.status === "approved").length / approvals.length) * 100)
                : 0}
              %
            </div>
            <div className="small text-muted">Approval Rate</div>
          </div>
        </div>
      </div>
    </div>
  )
}
