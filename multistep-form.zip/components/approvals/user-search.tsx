"use client"

import { useState, useRef, useEffect } from "react"
import { searchUsers, getTeamByExpert, type User } from "../../lib/mock-data"

interface UserSearchProps {
  onTeamAdd: (users: User[]) => void
  placeholder?: string
}

export default function UserSearch({ onTeamAdd, placeholder = "Search for expert name..." }: UserSearchProps) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<User[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Handle search input changes
  useEffect(() => {
    if (query.length >= 2) {
      setIsLoading(true)
      // Simulate API delay
      const timer = setTimeout(() => {
        const searchResults = searchUsers(query)
        setResults(searchResults)
        setIsOpen(searchResults.length > 0)
        setIsLoading(false)
      }, 300)

      return () => clearTimeout(timer)
    } else {
      setResults([])
      setIsOpen(false)
      setIsLoading(false)
    }
  }, [query])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleExpertSelect = (expert: User) => {
    const teamMembers = getTeamByExpert(expert.id)
    onTeamAdd(teamMembers)
    setQuery("")
    setIsOpen(false)
    inputRef.current?.blur()
  }

  return (
    <div className="position-relative" ref={searchRef}>
      <div className="input-group">
        <span className="input-group-text">
          <span className="material-icons">search</span>
        </span>
        <input
          ref={inputRef}
          type="text"
          className="form-control"
          placeholder={placeholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(results.length > 0)}
        />
        {isLoading && (
          <span className="input-group-text">
            <div className="spinner-border spinner-border-sm" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </span>
        )}
      </div>

      {/* Search Results Dropdown */}
      {isOpen && (
        <div className="dropdown-menu show w-100 mt-1" style={{ maxHeight: "300px", overflowY: "auto" }}>
          {results.length > 0 ? (
            results.map((user) => (
              <button
                key={user.id}
                type="button"
                className="dropdown-item d-flex align-items-center py-2"
                onClick={() => handleExpertSelect(user)}
              >
                <div className="me-3">
                  <div
                    className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                    style={{ width: "32px", height: "32px", fontSize: "14px" }}
                  >
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </div>
                </div>
                <div className="flex-grow-1">
                  <div className="fw-bold">{user.name}</div>
                  <div className="small text-muted">
                    {user.role} • {user.team} Team
                  </div>
                  <div className="small text-muted">{user.email}</div>
                </div>
                <div className="text-end">
                  <span className="badge bg-secondary">{user.team}</span>
                </div>
              </button>
            ))
          ) : (
            <div className="dropdown-item-text text-muted">
              <span className="material-icons me-2">info</span>
              No experts found matching "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  )
}
