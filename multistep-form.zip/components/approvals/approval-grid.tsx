"use client"

import { useState } from "react"
import type { UserApproval } from "../../lib/mock-data"

interface ApprovalGridProps {
  approvals: UserApproval[]
  onApprovalUpdate: (userId: string, status: "approved" | "rejected", comment: string) => void
  currentUserId?: string
}

export default function ApprovalGrid({ approvals, onApprovalUpdate, currentUserId = "1" }: ApprovalGridProps) {
  const [editingComments, setEditingComments] = useState<{ [key: string]: string }>({})

  const handleStatusChange = (userId: string, status: "approved" | "rejected") => {
    const comment = editingComments[userId] || ""
    onApprovalUpdate(userId, status, comment)
    setEditingComments((prev) => ({ ...prev, [userId]: "" }))
  }

  const handleCommentChange = (userId: string, comment: string) => {
    setEditingComments((prev) => ({ ...prev, [userId]: comment }))
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <span className="badge bg-success">Approved</span>
      case "rejected":
        return <span className="badge bg-danger">Rejected</span>
      default:
        return <span className="badge bg-warning">Pending</span>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <span className="material-icons text-success">check_circle</span>
      case "rejected":
        return <span className="material-icons text-danger">cancel</span>
      default:
        return <span className="material-icons text-warning">schedule</span>
    }
  }

  if (approvals.length === 0) {
    return (
      <div className="text-center py-5">
        <span className="material-icons text-muted mb-3" style={{ fontSize: "48px" }}>
          group_add
        </span>
        <h5 className="text-muted">No IRT Team Members Added</h5>
        <p className="text-muted">Search for an expert to add their entire team for approval.</p>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="card-header bg-primary text-white">
        <div className="d-flex align-items-center">
          <span className="material-icons me-2">how_to_vote</span>
          <h5 className="mb-0">IRT Team Approvals ({approvals.length} members)</h5>
        </div>
      </div>
      <div className="card-body p-0">
        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead className="table-light">
              <tr>
                <th style={{ width: "250px" }}>Team Member</th>
                <th style={{ width: "120px" }}>Team</th>
                <th style={{ width: "120px" }}>Status</th>
                <th style={{ width: "200px" }}>Actions</th>
                <th>Comments</th>
                <th style={{ width: "150px" }}>Approved At</th>
              </tr>
            </thead>
            <tbody>
              {approvals.map((approval) => {
                const isCurrentUser = approval.userId === currentUserId
                const canEdit = approval.canEdit && approval.status === "pending"
                const currentComment = editingComments[approval.userId] ?? approval.comment

                return (
                  <tr key={approval.userId} className={isCurrentUser ? "table-info" : ""}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="me-3">
                          <div
                            className="bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style={{ width: "32px", height: "32px", fontSize: "12px" }}
                          >
                            {approval.userName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                              .toUpperCase()}
                          </div>
                        </div>
                        <div>
                          <div className="fw-bold">
                            {approval.userName}
                            {isCurrentUser && <span className="badge bg-info ms-2">You</span>}
                          </div>
                          <div className="small text-muted">{approval.role}</div>
                          <div className="small text-muted">{approval.userEmail}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge bg-secondary">{approval.team}</span>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        {getStatusIcon(approval.status)}
                        <span className="ms-2">{getStatusBadge(approval.status)}</span>
                      </div>
                    </td>
                    <td>
                      {canEdit ? (
                        <div className="d-flex gap-1">
                          <button
                            type="button"
                            className="btn btn-sm btn-success"
                            onClick={() => handleStatusChange(approval.userId, "approved")}
                            title="Approve"
                          >
                            <span className="material-icons" style={{ fontSize: "16px" }}>
                              check
                            </span>
                          </button>
                          <button
                            type="button"
                            className="btn btn-sm btn-danger"
                            onClick={() => handleStatusChange(approval.userId, "rejected")}
                            title="Reject"
                          >
                            <span className="material-icons" style={{ fontSize: "16px" }}>
                              close
                            </span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-muted small">
                          {approval.status === "pending" ? "Awaiting response" : "Decision made"}
                        </span>
                      )}
                    </td>
                    <td>
                      {canEdit ? (
                        <textarea
                          className="form-control form-control-sm"
                          rows={2}
                          placeholder="Add your comments..."
                          value={currentComment}
                          onChange={(e) => handleCommentChange(approval.userId, e.target.value)}
                        />
                      ) : (
                        <div className="small">
                          {approval.comment || <span className="text-muted">No comments</span>}
                        </div>
                      )}
                    </td>
                    <td>
                      {approval.approvedAt ? (
                        <div className="small">
                          {new Date(approval.approvedAt).toLocaleDateString()}
                          <br />
                          <span className="text-muted">{new Date(approval.approvedAt).toLocaleTimeString()}</span>
                        </div>
                      ) : (
                        <span className="text-muted small">-</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
      <div className="card-footer bg-light">
        <div className="row">
          <div className="col-md-3">
            <div className="text-center">
              <div className="h5 mb-0 text-success">{approvals.filter((a) => a.status === "approved").length}</div>
              <div className="small text-muted">Approved</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <div className="h5 mb-0 text-danger">{approvals.filter((a) => a.status === "rejected").length}</div>
              <div className="small text-muted">Rejected</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <div className="h5 mb-0 text-warning">{approvals.filter((a) => a.status === "pending").length}</div>
              <div className="small text-muted">Pending</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="text-center">
              <div className="h5 mb-0 text-primary">
                {Math.round((approvals.filter((a) => a.status === "approved").length / approvals.length) * 100) || 0}%
              </div>
              <div className="small text-muted">Approval Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
