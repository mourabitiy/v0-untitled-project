"use client"

import { useState, useRef, useEffect } from "react"
import { searchUsers, type User } from "../../lib/mock-data"

interface ProfessionalUserSearchProps {
  onUserAdd: (user: User) => void
  addedUserIds: string[]
}

export default function ProfessionalUserSearch({ onUserAdd, addedUserIds }: ProfessionalUserSearchProps) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<User[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (query.length >= 2) {
      setIsLoading(true)
      const timer = setTimeout(() => {
        const searchResults = searchUsers(query).filter((user) => !addedUserIds.includes(user.id))
        setResults(searchResults)
        setIsOpen(searchResults.length > 0)
        setIsLoading(false)
      }, 300)

      return () => clearTimeout(timer)
    } else {
      setResults([])
      setIsOpen(false)
      setIsLoading(false)
    }
  }, [query, addedUserIds])

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleUserAdd = (user: User) => {
    onUserAdd(user)
    setQuery("")
    setIsOpen(false)
    inputRef.current?.focus()
  }

  return (
    <div className="mb-4">
      <label className="form-label fw-medium text-dark mb-2">Add IRT Team Members</label>
      <div className="position-relative" ref={searchRef}>
        <div className="input-group">
          <span className="input-group-text bg-white border-end-0">
            <span className="material-icons text-muted" style={{ fontSize: "20px" }}>
              search
            </span>
          </span>
          <input
            ref={inputRef}
            type="text"
            className="form-control border-start-0 ps-0"
            placeholder="Search by name, email, or role..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsOpen(results.length > 0)}
            style={{ boxShadow: "none" }}
          />
          {isLoading && (
            <span className="input-group-text bg-white">
              <div className="spinner-border spinner-border-sm text-muted" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </span>
          )}
        </div>

        {/* Search Results */}
        {isOpen && (
          <div
            className="position-absolute w-100 bg-white border rounded-3 shadow-sm mt-1"
            style={{ zIndex: 1000, maxHeight: "320px", overflowY: "auto" }}
          >
            {results.length > 0 ? (
              <div className="p-2">
                {results.map((user, index) => (
                  <div
                    key={user.id}
                    className={`d-flex align-items-center p-3 rounded-2 ${
                      index > 0 ? "border-top" : ""
                    } hover-bg-light`}
                    style={{ cursor: "pointer", transition: "background-color 0.15s ease" }}
                  >
                    <div className="me-3">
                      <div
                        className="bg-light text-dark rounded-circle d-flex align-items-center justify-content-center fw-medium"
                        style={{ width: "40px", height: "40px", fontSize: "14px" }}
                      >
                        {user.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()}
                      </div>
                    </div>
                    <div className="flex-grow-1">
                      <div className="fw-medium text-dark mb-1">{user.name}</div>
                      <div className="text-muted small">{user.role}</div>
                      <div className="text-muted small">{user.email}</div>
                    </div>
                    <div className="text-end">
                      <div className="text-muted small mb-2">{user.team}</div>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleUserAdd(user)}
                      >
                        <span className="material-icons me-1" style={{ fontSize: "16px" }}>
                          add
                        </span>
                        Add
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-muted">
                <span className="material-icons mb-2" style={{ fontSize: "24px" }}>
                  search_off
                </span>
                <div className="small">
                  {query.length < 2 ? "Type at least 2 characters to search" : `No users found matching "${query}"`}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
