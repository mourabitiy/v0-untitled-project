"use client"

import { useState, useRef, useEffect } from "react"
import { searchUsers, type User } from "../../lib/mock-data"

interface IndividualUserSearchProps {
  onUserAdd: (user: User) => void
  addedUserIds: string[]
}

export default function IndividualUserSearch({ onUserAdd, addedUserIds }: IndividualUserSearchProps) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<User[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Handle search input changes
  useEffect(() => {
    if (query.length >= 2) {
      setIsLoading(true)
      const timer = setTimeout(() => {
        const searchResults = searchUsers(query).filter((user) => !addedUserIds.includes(user.id))
        setResults(searchResults)
        setIsOpen(searchResults.length > 0)
        setIsLoading(false)
      }, 300)

      return () => clearTimeout(timer)
    } else {
      setResults([])
      setIsOpen(false)
      setIsLoading(false)
    }
  }, [query, addedUserIds])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleUserAdd = (user: User) => {
    onUserAdd(user)
    setQuery("")
    setIsOpen(false)
    inputRef.current?.focus()
  }

  return (
    <div className="position-relative" ref={searchRef}>
      <div className="input-group">
        <span className="input-group-text">
          <span className="material-icons">person_search</span>
        </span>
        <input
          ref={inputRef}
          type="text"
          className="form-control"
          placeholder="Search user to add to IRT..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(results.length > 0)}
        />
        {isLoading && (
          <span className="input-group-text">
            <div className="spinner-border spinner-border-sm" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </span>
        )}
      </div>

      {/* Search Results Dropdown */}
      {isOpen && (
        <div className="dropdown-menu show w-100 mt-1" style={{ maxHeight: "300px", overflowY: "auto" }}>
          {results.length > 0 ? (
            results.map((user) => (
              <div key={user.id} className="dropdown-item d-flex align-items-center justify-content-between py-2">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div
                      className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "32px", height: "32px", fontSize: "14px" }}
                    >
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase()}
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <div className="fw-bold">{user.name}</div>
                    <div className="small text-muted">
                      {user.role} • {user.team}
                    </div>
                    <div className="small text-muted">{user.email}</div>
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={() => handleUserAdd(user)}
                  title="Add to IRT"
                >
                  <span className="material-icons" style={{ fontSize: "16px" }}>
                    add
                  </span>
                </button>
              </div>
            ))
          ) : (
            <div className="dropdown-item-text text-muted">
              <span className="material-icons me-2">info</span>
              {query.length < 2 ? "Type at least 2 characters to search" : `No users found matching "${query}"`}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
