"use client"

import type { FileObject } from "../file-upload/file-types"

interface InitializationData {
  projectTitle: string
  projectCode: string
  department: string
  budget: string
  description: string
  initiatorName: string
  initiatorEmail: string
  files: FileObject[]
}

interface DataDisplayProps {
  data: InitializationData
}

export default function DataDisplay({ data }: DataDisplayProps) {
  const formatFileSize = (bytes: number) => {
    return (bytes / 1024).toFixed(1) + " KB"
  }

  const getFileTypeLabel = (type: string) => {
    const types: { [key: string]: string } = {
      excel: "Excel Spreadsheet",
      csv: "CSV File",
    }
    return types[type] || "Unknown"
  }

  const formatBudget = (budget: string) => {
    const num = Number.parseFloat(budget)
    return isNaN(num) ? budget : `$${num.toLocaleString()}`
  }

  return (
    <div className="card border-0 bg-light">
      <div className="card-header bg-primary text-white">
        <div className="d-flex align-items-center">
          <span className="material-icons me-2">assignment</span>
          <h5 className="mb-0">Project Information Review</h5>
        </div>
      </div>
      <div className="card-body">
        <div className="row g-4">
          {/* Project Details */}
          <div className="col-md-6">
            <div className="card h-100">
              <div className="card-header bg-light">
                <div className="d-flex align-items-center">
                  <span className="material-icons me-2 text-primary">info</span>
                  <h6 className="mb-0">Project Details</h6>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label text-muted small">Project Title</label>
                  <div className="fw-bold">{data.projectTitle}</div>
                </div>
                <div className="mb-3">
                  <label className="form-label text-muted small">Project Code</label>
                  <div className="fw-bold">
                    <span className="badge bg-secondary">{data.projectCode}</span>
                  </div>
                </div>
                <div className="mb-3">
                  <label className="form-label text-muted small">Department</label>
                  <div className="fw-bold text-capitalize">{data.department}</div>
                </div>
                <div className="mb-0">
                  <label className="form-label text-muted small">Budget</label>
                  <div className="fw-bold text-success">{formatBudget(data.budget)}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Initiator Information */}
          <div className="col-md-6">
            <div className="card h-100">
              <div className="card-header bg-light">
                <div className="d-flex align-items-center">
                  <span className="material-icons me-2 text-primary">person</span>
                  <h6 className="mb-0">Initiator Information</h6>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label text-muted small">Name</label>
                  <div className="fw-bold">{data.initiatorName}</div>
                </div>
                <div className="mb-0">
                  <label className="form-label text-muted small">Email</label>
                  <div className="fw-bold">
                    <a href={`mailto:${data.initiatorEmail}`} className="text-decoration-none">
                      {data.initiatorEmail}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Project Description */}
          <div className="col-12">
            <div className="card">
              <div className="card-header bg-light">
                <div className="d-flex align-items-center">
                  <span className="material-icons me-2 text-primary">description</span>
                  <h6 className="mb-0">Project Description</h6>
                </div>
              </div>
              <div className="card-body">
                <p className="mb-0">{data.description}</p>
              </div>
            </div>
          </div>

          {/* Uploaded Files */}
          {data.files && data.files.length > 0 && (
            <div className="col-12">
              <div className="card">
                <div className="card-header bg-light">
                  <div className="d-flex align-items-center">
                    <span className="material-icons me-2 text-primary">attach_file</span>
                    <h6 className="mb-0">Uploaded Files ({data.files.length})</h6>
                  </div>
                </div>
                <div className="card-body">
                  <div className="row g-3">
                    {data.files.map((file) => (
                      <div key={file.id} className="col-md-6">
                        <div className="card border">
                          <div className="card-body p-3">
                            <div className="d-flex align-items-center">
                              <span className="material-icons me-2 text-success">
                                {file.type === "csv" ? "grid_on" : "table_chart"}
                              </span>
                              <div className="flex-grow-1">
                                <div className="fw-bold text-truncate" style={{ maxWidth: "200px" }}>
                                  {file.file.name}
                                </div>
                                <div className="small text-muted">
                                  {getFileTypeLabel(file.type)} • {formatFileSize(file.file.size)}
                                </div>
                              </div>
                              <span className="badge bg-success">
                                <span className="material-icons" style={{ fontSize: "14px" }}>
                                  check_circle
                                </span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
