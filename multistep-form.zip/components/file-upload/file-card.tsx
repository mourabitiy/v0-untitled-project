"use client"

import { type FileObject, getFileTypeIcon, FILE_TYPES } from "./file-types"

interface FileCardProps {
  file: FileObject
  onRemove: (fileId: string) => void
  onTypeChange: (fileId: string, type: string) => void
}

export default function FileCard({ file, onRemove, onTypeChange }: FileCardProps) {
  const fileTypeIcon = getFileTypeIcon(file.type)

  const getFileStatusIcon = () => {
    if (file.error) return "error"
    if (file.uploaded) return "check_circle"
    return "schedule"
  }

  const getFileStatusClass = () => {
    if (file.error) return "text-danger"
    if (file.uploaded) return "text-success"
    return "text-warning"
  }

  return (
    <div className={`card h-100 ${file.error ? "border-danger" : ""}`}>
      <div className="card-body p-3">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <div className="d-flex align-items-center">
            <div className="me-2">
              <span className={`material-icons ${getFileStatusClass()}`} style={{ fontSize: "18px" }}>
                {getFileStatusIcon()}
              </span>
            </div>
            <div className="text-truncate" style={{ maxWidth: "180px" }}>
              <span className={file.error ? "text-danger" : ""}>{file.file.name}</span>
              <div className="small text-muted">{(file.file.size / 1024).toFixed(1)} KB</div>
            </div>
          </div>
          <button type="button" className="btn btn-sm btn-light rounded-circle" onClick={() => onRemove(file.id)}>
            <span className="material-icons" style={{ fontSize: "16px" }}>
              close
            </span>
          </button>
        </div>

        {file.error ? (
          <div className="text-danger small mb-2">{file.error}</div>
        ) : (
          <div className="progress mb-2" style={{ height: "6px" }}>
            <div
              className={`progress-bar ${file.uploaded ? "bg-success" : "bg-primary"}`}
              role="progressbar"
              style={{ width: `${file.progress}%` }}
              aria-valuenow={file.progress}
              aria-valuemin={0}
              aria-valuemax={100}
            ></div>
          </div>
        )}

        <div className="d-flex justify-content-between align-items-center">
          <div className="w-75">
            <select
              className="form-select form-select-sm"
              value={file.type}
              onChange={(e) => onTypeChange(file.id, e.target.value)}
              disabled={!file.uploaded && !file.error}
            >
              <option value="" disabled>
                Select file type
              </option>
              {FILE_TYPES.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>
          <div className="small text-end">
            {file.error ? (
              <span className="text-danger">Error</span>
            ) : file.uploaded ? (
              <span className="text-success">Uploaded</span>
            ) : (
              <span className="text-muted">{file.progress}%</span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
