"use client"

import { useState } from "react"
import UploadArea from "./upload-area"
import FileCard from "./file-card"
import { type FileObject, MAX_FILE_SIZE } from "./file-types"

interface FileUploadManagerProps {
  files: FileObject[]
  setFiles: (files: FileObject[]) => void
  error?: string
}

export default function FileUploadManager({ files, setFiles, error }: FileUploadManagerProps) {
  const [isDragging, setIsDragging] = useState(false)

  const processFiles = (fileList: File[]) => {
    const newFiles: FileObject[] = []

    fileList.forEach((file) => {
      // Check file size
      if (file.size > MAX_FILE_SIZE) {
        const fileObj: FileObject = {
          id: crypto.randomUUID(),
          file,
          type: "excel", // Default to excel
          progress: 100,
          error: "File size exceeds 10MB limit",
          uploaded: false,
        }
        newFiles.push(fileObj)
        return
      }

      // Determine default type based on extension
      let defaultType = "excel"
      if (file.name.toLowerCase().endsWith(".csv")) {
        defaultType = "csv"
      }

      const fileObj: FileObject = {
        id: crypto.randomUUID(),
        file,
        type: defaultType,
        progress: 0,
        uploaded: false,
      }
      newFiles.push(fileObj)
    })

    setFiles((prev) => [...prev, ...newFiles])

    // Simulate upload process for each file
    newFiles.forEach((fileObj) => {
      if (fileObj.error) return // Skip files with errors
      simulateFileUpload(fileObj.id)
    })
  }

  const simulateFileUpload = (fileId: string) => {
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 10) + 5

      if (progress >= 100) {
        progress = 100
        clearInterval(interval)

        setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, progress: 100, uploaded: true } : f)))
      } else {
        setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, progress } : f)))
      }
    }, 300)
  }

  const removeFile = (fileId: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId))
  }

  const updateFileType = (fileId: string, newType: string) => {
    setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, type: newType } : f)))
  }

  return (
    <div className={`card mb-4 border-0 ${error ? "border border-danger" : "bg-light"}`}>
      <div className="card-header bg-light border-0">
        <div className="d-flex align-items-center">
          <span className="material-icons me-2 text-primary">description</span>
          <h5 className="mb-0">Project Documents</h5>
        </div>
        <p className="text-muted small mb-0">Upload Excel and CSV files only</p>
      </div>
      <div className="card-body">
        <UploadArea onFilesSelected={processFiles} isDragging={isDragging} setIsDragging={setIsDragging} />

        {/* File List */}
        {files.length > 0 && (
          <div className="mt-4">
            <div className="d-flex align-items-center mb-3">
              <span className="material-icons me-2 text-primary" style={{ fontSize: "18px" }}>
                folder
              </span>
              <h6 className="mb-0">Uploaded Files ({files.length})</h6>
            </div>
            <div className="row g-3">
              {files.map((file) => (
                <div key={file.id} className="col-md-6">
                  <FileCard file={file} onRemove={removeFile} onTypeChange={updateFileType} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
