// Define allowed file types - Excel files only
export const FILE_TYPES = [
  {
    value: "excel",
    label: "Excel Spreadsheet",
    icon: "table_chart",
    accept: ".xlsx,.xls",
  },
  {
    value: "csv",
    label: "CSV File",
    icon: "grid_on",
    accept: ".csv",
  },
]

// Define the file object structure
export interface FileObject {
  id: string
  file: File
  type: string
  progress: number
  error?: string
  uploaded: boolean
}

export const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB

export const isExcelFile = (file: File): boolean => {
  const excelTypes = [
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/csv",
  ]

  // Check by MIME type
  if (excelTypes.includes(file.type)) {
    return true
  }

  // Check by extension as fallback
  const extension = file.name.split(".").pop()?.toLowerCase()
  return extension === "xlsx" || extension === "xls" || extension === "csv"
}

export const getFileTypeIcon = (type: string): string => {
  const fileType = FILE_TYPES.find((t) => t.value === type)
  return fileType?.icon || "description"
}
