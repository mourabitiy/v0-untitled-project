import { CheckIcon } from "lucide-react"

interface FormTimelineProps {
  steps: string[]
  currentStep: number
}

export default function FormTimeline({ steps, currentStep }: FormTimelineProps) {
  return (
    <div className="relative mb-12">
      <div className="absolute inset-0 flex items-center">
        <div className="w-full h-1 bg-gray-200 rounded"></div>
      </div>
      <ol className="relative z-10 flex justify-between">
        {steps.map((step, index) => (
          <li key={step} className="flex items-center">
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${
                index < currentStep
                  ? "bg-primary border-primary text-white"
                  : index === currentStep
                    ? "border-primary text-primary bg-white"
                    : "border-gray-300 text-gray-300 bg-white"
              }`}
            >
              {index < currentStep ? <CheckIcon className="h-6 w-6" /> : <span>{index + 1}</span>}
            </div>
            <span
              className={`absolute mt-16 -ml-8 w-24 text-center text-sm ${
                index <= currentStep ? "text-gray-900" : "text-gray-400"
              }`}
            >
              {step}
            </span>
          </li>
        ))}
      </ol>
    </div>
  )
}
