"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import ProfessionalUserSearch from "../approvals/professional-user-search"
import ProfessionalApprovalInterface from "../approvals/professional-approval-interface"
import type { User, UserApproval } from "../../lib/mock-data"

const approvalSchema = z.object({
  irtCoordinator: z.string().min(2, { message: "IRT Coordinator name is required" }),
  coordinatorEmail: z.string().email({ message: "Invalid email address" }),
  processDate: z.string({ required_error: "Process date is required" }),
  approvals: z.array(z.any()).min(1, { message: "At least one team member must be added for approval" }),
  allApproved: z.boolean().refine((val) => val === true, {
    message: "All team members must approve before completing the process",
  }),
})

type ApprovalValues = z.infer<typeof approvalSchema>

interface ApprovalStepProps {
  onComplete: (data: ApprovalValues) => void
  existingData: ApprovalValues | null
}

export default function ApprovalStep({ onComplete, existingData }: ApprovalStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [approvals, setApprovals] = useState<UserApproval[]>(existingData?.approvals || [])
  const [currentUserId] = useState("1") // Mock current user ID

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
  } = useForm<ApprovalValues>({
    resolver: zodResolver(approvalSchema),
    defaultValues: existingData || {
      irtCoordinator: "",
      coordinatorEmail: "",
      processDate: new Date().toISOString().split("T")[0],
      approvals: [],
      allApproved: false,
    },
  })

  const updateFormApprovals = (newApprovals: UserApproval[]) => {
    setApprovals(newApprovals)
    setValue("approvals", newApprovals)
    setValue("allApproved", newApprovals.length > 0 && newApprovals.every((a) => a.status === "approved"))
    trigger(["approvals", "allApproved"])
  }

  const handleUserAdd = (user: User) => {
    const newApproval: UserApproval = {
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      team: user.team,
      role: user.role,
      status: "pending",
      comment: "",
      canEdit: user.id === currentUserId,
    }

    updateFormApprovals([...approvals, newApproval])
  }

  const handleApprovalUpdate = (userId: string, status: "approved" | "rejected", comment: string) => {
    const updatedApprovals = approvals.map((approval) =>
      approval.userId === userId
        ? {
            ...approval,
            status,
            comment,
            approvedAt: new Date().toISOString(),
            canEdit: false,
          }
        : approval,
    )
    updateFormApprovals(updatedApprovals)
  }

  const handleUserRemove = (userId: string) => {
    const updatedApprovals = approvals.filter((approval) => approval.userId !== userId)
    updateFormApprovals(updatedApprovals)
  }

  async function onSubmit(values: ApprovalValues) {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const approvalStats = {
    total: approvals.length,
    approved: approvals.filter((a) => a.status === "approved").length,
    pending: approvals.filter((a) => a.status === "pending").length,
  }

  const addedUserIds = approvals.map((a) => a.userId)

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Coordinator Information */}
        <div className="card border-0 shadow-sm mb-4">
          <div className="card-header bg-white border-bottom">
            <h6 className="mb-0 fw-medium">IRT Coordinator Information</h6>
          </div>
          <div className="card-body">
            <div className="row g-4">
              <div className="col-md-4">
                <label htmlFor="irtCoordinator" className="form-label fw-medium text-dark">
                  Coordinator Name
                </label>
                <input
                  id="irtCoordinator"
                  type="text"
                  className={`form-control ${errors.irtCoordinator ? "is-invalid" : ""}`}
                  placeholder="Enter your full name"
                  {...register("irtCoordinator")}
                />
                {errors.irtCoordinator && <div className="invalid-feedback">{errors.irtCoordinator.message}</div>}
              </div>

              <div className="col-md-4">
                <label htmlFor="coordinatorEmail" className="form-label fw-medium text-dark">
                  Email Address
                </label>
                <input
                  id="coordinatorEmail"
                  type="email"
                  className={`form-control ${errors.coordinatorEmail ? "is-invalid" : ""}`}
                  placeholder="your.email@company.com"
                  {...register("coordinatorEmail")}
                />
                {errors.coordinatorEmail && <div className="invalid-feedback">{errors.coordinatorEmail.message}</div>}
              </div>

              <div className="col-md-4">
                <label htmlFor="processDate" className="form-label fw-medium text-dark">
                  Process Date
                </label>
                <input
                  id="processDate"
                  type="date"
                  className={`form-control ${errors.processDate ? "is-invalid" : ""}`}
                  {...register("processDate")}
                />
                {errors.processDate && <div className="invalid-feedback">{errors.processDate.message}</div>}
              </div>
            </div>
          </div>
        </div>

        {/* User Search */}
        <div className="card border-0 shadow-sm mb-4">
          <div className="card-body">
            <ProfessionalUserSearch onUserAdd={handleUserAdd} addedUserIds={addedUserIds} />
            {errors.approvals && <div className="text-danger small">{errors.approvals.message}</div>}
          </div>
        </div>

        {/* Approval Interface */}
        <div className="mb-4">
          <ProfessionalApprovalInterface
            approvals={approvals}
            onApprovalUpdate={handleApprovalUpdate}
            onUserRemove={handleUserRemove}
            currentUserId={currentUserId}
          />
        </div>

        {/* Process Status */}
        {approvals.length > 0 && (
          <div className={`alert ${approvalStats.pending > 0 ? "alert-warning" : "alert-success"} border-0 mb-4`}>
            <div className="d-flex align-items-center">
              <span className="material-icons me-3" style={{ fontSize: "24px" }}>
                {approvalStats.pending > 0 ? "schedule" : "check_circle"}
              </span>
              <div>
                <div className="fw-medium">
                  {approvalStats.pending > 0 ? "Approval Process In Progress" : "All Approvals Complete"}
                </div>
                <div className="small text-muted mt-1">
                  {approvalStats.approved} of {approvalStats.total} team members have approved
                  {approvalStats.pending > 0 && " • Waiting for remaining responses"}
                </div>
                {errors.allApproved && <div className="text-danger small mt-2">{errors.allApproved.message}</div>}
              </div>
            </div>
          </div>
        )}

        {/* Submit Button */}
        <div className="d-flex justify-content-end">
          <button type="submit" className="btn btn-primary px-4" disabled={isSubmitting || approvalStats.pending > 0}>
            {isSubmitting ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Processing...
              </>
            ) : (
              <>
                <span className="material-icons me-2" style={{ fontSize: "18px" }}>
                  task_alt
                </span>
                Complete IRT Process
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
