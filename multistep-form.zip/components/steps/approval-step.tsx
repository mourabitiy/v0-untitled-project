"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import UserSearch from "../approvals/user-search"
import ApprovalGrid from "../approvals/approval-grid"
import type { User, UserApproval } from "../../lib/mock-data"

const approvalSchema = z.object({
  irtCoordinator: z.string().min(2, { message: "IRT Coordinator name is required" }),
  coordinatorEmail: z.string().email({ message: "Invalid email address" }),
  processDate: z.string({ required_error: "Process date is required" }),
  approvals: z.array(z.any()).min(1, { message: "At least one IRT team must be added for approval" }),
  allApproved: z.boolean().refine((val) => val === true, {
    message: "All team members must approve before completing the process",
  }),
})

type ApprovalValues = z.infer<typeof approvalSchema>

interface ApprovalStepProps {
  onComplete: (data: ApprovalValues) => void
  existingData: ApprovalValues | null
}

export default function ApprovalStep({ onComplete, existingData }: ApprovalStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [approvals, setApprovals] = useState<UserApproval[]>(existingData?.approvals || [])
  const [currentUserId] = useState("1") // Mock current user ID (Alice Johnson)

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
  } = useForm<ApprovalValues>({
    resolver: zodResolver(approvalSchema),
    defaultValues: existingData || {
      irtCoordinator: "",
      coordinatorEmail: "",
      processDate: new Date().toISOString().split("T")[0],
      approvals: [],
      allApproved: false,
    },
  })

  // Update form when approvals change
  const updateFormApprovals = (newApprovals: UserApproval[]) => {
    setApprovals(newApprovals)
    setValue("approvals", newApprovals)
    setValue("allApproved", newApprovals.length > 0 && newApprovals.every((a) => a.status === "approved"))
    trigger(["approvals", "allApproved"])
  }

  const handleTeamAdd = (users: User[]) => {
    const newApprovals = users.map(
      (user): UserApproval => ({
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        team: user.team,
        role: user.role,
        status: "pending",
        comment: "",
        canEdit: user.id === currentUserId, // Only current user can edit their own approval
      }),
    )

    // Avoid duplicate users
    const existingUserIds = new Set(approvals.map((a) => a.userId))
    const uniqueNewApprovals = newApprovals.filter((approval) => !existingUserIds.has(approval.userId))

    if (uniqueNewApprovals.length > 0) {
      updateFormApprovals([...approvals, ...uniqueNewApprovals])
    }
  }

  const handleApprovalUpdate = (userId: string, status: "approved" | "rejected", comment: string) => {
    const updatedApprovals = approvals.map((approval) =>
      approval.userId === userId
        ? {
            ...approval,
            status,
            comment,
            approvedAt: new Date().toISOString(),
            canEdit: false, // Lock editing after decision
          }
        : approval,
    )
    updateFormApprovals(updatedApprovals)
  }

  const handleRemoveTeam = (teamName: string) => {
    const updatedApprovals = approvals.filter((approval) => approval.team !== teamName)
    updateFormApprovals(updatedApprovals)
  }

  async function onSubmit(values: ApprovalValues) {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Get unique teams
  const teams = [...new Set(approvals.map((a) => a.team))]
  const approvalStats = {
    total: approvals.length,
    approved: approvals.filter((a) => a.status === "approved").length,
    rejected: approvals.filter((a) => a.status === "rejected").length,
    pending: approvals.filter((a) => a.status === "pending").length,
  }

  return (
    <div className="card">
      <div className="card-body">
        <form onSubmit={handleSubmit(onSubmit)}>
          {/* IRT Coordinator Information */}
          <div className="card mb-4">
            <div className="card-header bg-info text-white">
              <div className="d-flex align-items-center">
                <span className="material-icons me-2">admin_panel_settings</span>
                <h5 className="mb-0">IRT Coordinator Information</h5>
              </div>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-md-4">
                  <label htmlFor="irtCoordinator" className="form-label">
                    IRT Coordinator Name
                  </label>
                  <input
                    id="irtCoordinator"
                    type="text"
                    className={`form-control ${errors.irtCoordinator ? "is-invalid" : ""}`}
                    placeholder="Your name"
                    {...register("irtCoordinator")}
                  />
                  {errors.irtCoordinator && <div className="invalid-feedback">{errors.irtCoordinator.message}</div>}
                </div>

                <div className="col-md-4">
                  <label htmlFor="coordinatorEmail" className="form-label">
                    Coordinator Email
                  </label>
                  <input
                    id="coordinatorEmail"
                    type="email"
                    className={`form-control ${errors.coordinatorEmail ? "is-invalid" : ""}`}
                    placeholder="your.email@company.com"
                    {...register("coordinatorEmail")}
                  />
                  {errors.coordinatorEmail && <div className="invalid-feedback">{errors.coordinatorEmail.message}</div>}
                </div>

                <div className="col-md-4">
                  <label htmlFor="processDate" className="form-label">
                    Process Date
                  </label>
                  <input
                    id="processDate"
                    type="date"
                    className={`form-control ${errors.processDate ? "is-invalid" : ""}`}
                    {...register("processDate")}
                  />
                  {errors.processDate && <div className="invalid-feedback">{errors.processDate.message}</div>}
                </div>
              </div>
            </div>
          </div>

          {/* Team Search and Management */}
          <div className="card mb-4">
            <div className="card-header bg-warning text-dark">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <span className="material-icons me-2">group_add</span>
                  <h5 className="mb-0">Add IRT Teams</h5>
                </div>
                {teams.length > 0 && (
                  <div className="d-flex gap-2">
                    {teams.map((team) => (
                      <div key={team} className="d-flex align-items-center">
                        <span className="badge bg-secondary me-2">{team}</span>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => handleRemoveTeam(team)}
                          title={`Remove ${team} team`}
                        >
                          <span className="material-icons" style={{ fontSize: "14px" }}>
                            close
                          </span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="card-body">
              <UserSearch onTeamAdd={handleTeamAdd} placeholder="Search for an expert to add their entire team..." />
              {errors.approvals && <div className="text-danger small mt-2">{errors.approvals.message}</div>}

              {teams.length > 0 && (
                <div className="mt-3">
                  <div className="alert alert-info">
                    <span className="material-icons me-2">info</span>
                    <strong>Teams Added:</strong> {teams.join(", ")} ({approvals.length} members total)
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Approval Grid */}
          <div className="mb-4">
            <ApprovalGrid approvals={approvals} onApprovalUpdate={handleApprovalUpdate} currentUserId={currentUserId} />
          </div>

          {/* Completion Requirements */}
          {approvals.length > 0 && (
            <div className={`alert ${approvalStats.pending > 0 ? "alert-warning" : "alert-success"} mb-4`}>
              <div className="d-flex align-items-center">
                <span className="material-icons me-2">{approvalStats.pending > 0 ? "schedule" : "check_circle"}</span>
                <div>
                  <strong>Approval Status:</strong> {approvalStats.approved} approved, {approvalStats.rejected}{" "}
                  rejected, {approvalStats.pending} pending
                  {approvalStats.pending > 0 && (
                    <div className="small mt-1">
                      All team members must provide their approval before the process can be completed.
                    </div>
                  )}
                  {errors.allApproved && <div className="text-danger small mt-1">{errors.allApproved.message}</div>}
                </div>
              </div>
            </div>
          )}

          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary" disabled={isSubmitting || approvalStats.pending > 0}>
              {isSubmitting ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Finalizing...
                </>
              ) : (
                <>
                  <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                    task_alt
                  </span>
                  Complete IRT Process
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
