"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"

const approvalSchema = z.object({
  decision: z.enum(["approved", "rejected", "conditional"], {
    required_error: "Please select a decision",
  }),
  approverName: z.string().min(2, { message: "Approver name is required" }),
  approverTitle: z.string().min(2, { message: "Approver title is required" }),
  approvalDate: z.date({ required_error: "Approval date is required" }),
  comments: z.string().optional(),
  conditions: z
    .string()
    .optional()
    .refine(
      (val) => {
        // If decision is conditional, conditions should be provided
        return true
      },
      {
        message: "Conditions are required for conditional approval",
      },
    ),
  nextSteps: z.string().optional(),
  signature: z.string().min(2, { message: "Digital signature is required" }),
})

type ApprovalValues = z.infer<typeof approvalSchema>

interface ApprovalStepProps {
  onComplete: (data: ApprovalValues) => void
  existingData: ApprovalValues | null
}

export default function ApprovalStep({ onComplete, existingData }: ApprovalStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [decision, setDecision] = useState(existingData?.decision || "approved")

  const form = useForm<ApprovalValues>({
    resolver: zodResolver(approvalSchema),
    defaultValues: existingData || {
      decision: "approved",
      approverName: "",
      approverTitle: "",
      approvalDate: new Date(),
      comments: "",
      conditions: "",
      nextSteps: "",
      signature: "",
    },
  })

  async function onSubmit(values: ApprovalValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="decision"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Decision</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={(value) => {
                        field.onChange(value)
                        setDecision(value as "approved" | "rejected" | "conditional")
                      }}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="approved" />
                        </FormControl>
                        <FormLabel className="font-normal">Approved</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="conditional" />
                        </FormControl>
                        <FormLabel className="font-normal">Conditionally Approved</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="rejected" />
                        </FormControl>
                        <FormLabel className="font-normal">Rejected</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="approverName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Approver Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="approverTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Approver Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Your job title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="approvalDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Approval Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button variant={"outline"} className="pl-3 text-left font-normal">
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="signature"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Digital Signature</FormLabel>
                    <FormControl>
                      <Input placeholder="Type your full name as signature" {...field} />
                    </FormControl>
                    <FormDescription>Your typed name serves as a digital signature</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Comments</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Additional comments regarding the decision"
                      className="min-h-20"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {decision === "conditional" && (
              <FormField
                control={form.control}
                name="conditions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Approval Conditions</FormLabel>
                    <FormControl>
                      <Textarea placeholder="List the conditions that must be met" className="min-h-20" {...field} />
                    </FormControl>
                    <FormDescription>Specify the conditions that must be met for full approval</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="nextSteps"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Next Steps</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Outline the next steps for this project" className="min-h-20" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Finalizing..." : "Complete Process"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}
