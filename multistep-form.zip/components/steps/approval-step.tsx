"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

const approvalSchema = z.object({
  decision: z.enum(["approved", "rejected", "conditional"], {
    required_error: "Please select a decision",
  }),
  approverName: z.string().min(2, { message: "Approver name is required" }),
  approverTitle: z.string().min(2, { message: "Approver title is required" }),
  approvalDate: z.string({ required_error: "Approval date is required" }),
  comments: z.string().optional(),
  conditions: z
    .string()
    .optional()
    .refine(
      (val, ctx) => {
        // If decision is conditional, conditions should be provided
        if (ctx.parent.decision === "conditional" && (!val || val.length < 5)) {
          return false
        }
        return true
      },
      {
        message: "Conditions are required for conditional approval",
      },
    ),
  nextSteps: z.string().optional(),
  signature: z.string().min(2, { message: "Digital signature is required" }),
})

type ApprovalValues = z.infer<typeof approvalSchema>

interface ApprovalStepProps {
  onComplete: (data: ApprovalValues) => void
  existingData: ApprovalValues | null
}

export default function ApprovalStep({ onComplete, existingData }: ApprovalStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<ApprovalValues>({
    resolver: zodResolver(approvalSchema),
    defaultValues: existingData || {
      decision: "approved",
      approverName: "",
      approverTitle: "",
      approvalDate: new Date().toISOString().split("T")[0],
      comments: "",
      conditions: "",
      nextSteps: "",
      signature: "",
    },
  })

  // Watch for changes to the decision field
  const decision = watch("decision")

  async function onSubmit(values: ApprovalValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="card">
      <div className="card-body">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-4">
            <label className="form-label">Decision</label>
            <div className="form-check">
              <input
                id="approved"
                type="radio"
                className="form-check-input"
                value="approved"
                {...register("decision")}
              />
              <label className="form-check-label" htmlFor="approved">
                Approved
              </label>
            </div>
            <div className="form-check">
              <input
                id="conditional"
                type="radio"
                className="form-check-input"
                value="conditional"
                {...register("decision")}
              />
              <label className="form-check-label" htmlFor="conditional">
                Conditionally Approved
              </label>
            </div>
            <div className="form-check">
              <input
                id="rejected"
                type="radio"
                className="form-check-input"
                value="rejected"
                {...register("decision")}
              />
              <label className="form-check-label" htmlFor="rejected">
                Rejected
              </label>
            </div>
            {errors.decision && <div className="text-danger small mt-1">{errors.decision.message}</div>}
          </div>

          <div className="row g-3 mb-3">
            <div className="col-md-6">
              <label htmlFor="approverName" className="form-label">
                Approver Name
              </label>
              <input
                id="approverName"
                type="text"
                className={`form-control ${errors.approverName ? "is-invalid" : ""}`}
                placeholder="Your name"
                {...register("approverName")}
              />
              {errors.approverName && <div className="invalid-feedback">{errors.approverName.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="approverTitle" className="form-label">
                Approver Title
              </label>
              <input
                id="approverTitle"
                type="text"
                className={`form-control ${errors.approverTitle ? "is-invalid" : ""}`}
                placeholder="Your job title"
                {...register("approverTitle")}
              />
              {errors.approverTitle && <div className="invalid-feedback">{errors.approverTitle.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="approvalDate" className="form-label">
                Approval Date
              </label>
              <input
                id="approvalDate"
                type="date"
                className={`form-control ${errors.approvalDate ? "is-invalid" : ""}`}
                {...register("approvalDate")}
              />
              {errors.approvalDate && <div className="invalid-feedback">{errors.approvalDate.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="signature" className="form-label">
                Digital Signature
              </label>
              <input
                id="signature"
                type="text"
                className={`form-control ${errors.signature ? "is-invalid" : ""}`}
                placeholder="Type your full name as signature"
                {...register("signature")}
              />
              <div className="form-text">Your typed name serves as a digital signature</div>
              {errors.signature && <div className="invalid-feedback">{errors.signature.message}</div>}
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="comments" className="form-label">
              Comments
            </label>
            <textarea
              id="comments"
              className={`form-control ${errors.comments ? "is-invalid" : ""}`}
              placeholder="Additional comments regarding the decision"
              rows={3}
              {...register("comments")}
            ></textarea>
            {errors.comments && <div className="invalid-feedback">{errors.comments.message}</div>}
          </div>

          {decision === "conditional" && (
            <div className="mb-3">
              <label htmlFor="conditions" className="form-label">
                Approval Conditions
              </label>
              <textarea
                id="conditions"
                className={`form-control ${errors.conditions ? "is-invalid" : ""}`}
                placeholder="List the conditions that must be met"
                rows={3}
                {...register("conditions")}
              ></textarea>
              <div className="form-text">Specify the conditions that must be met for full approval</div>
              {errors.conditions && <div className="invalid-feedback">{errors.conditions.message}</div>}
            </div>
          )}

          <div className="mb-3">
            <label htmlFor="nextSteps" className="form-label">
              Next Steps
            </label>
            <textarea
              id="nextSteps"
              className={`form-control ${errors.nextSteps ? "is-invalid" : ""}`}
              placeholder="Outline the next steps for this project"
              rows={3}
              {...register("nextSteps")}
            ></textarea>
            {errors.nextSteps && <div className="invalid-feedback">{errors.nextSteps.message}</div>}
          </div>

          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
              {isSubmitting ? "Finalizing..." : "Complete Process"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
