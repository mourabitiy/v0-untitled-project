"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const initializationSchema = z.object({
  projectTitle: z.string().min(3, { message: "Project title must be at least 3 characters" }),
  projectCode: z.string().min(2, { message: "Project code is required" }),
  department: z.string({ required_error: "Please select a department" }),
  budget: z.string().refine((val) => !isNaN(Number.parseFloat(val)), {
    message: "Budget must be a valid number",
  }),
  description: z.string().min(20, { message: "Description must be at least 20 characters" }),
  initiatorName: z.string().min(2, { message: "Initiator name is required" }),
  initiatorEmail: z.string().email({ message: "Invalid email address" }),
})

type InitializationValues = z.infer<typeof initializationSchema>

interface InitializationStepProps {
  onComplete: (data: InitializationValues) => void
  existingData: InitializationValues | null
}

export default function InitializationStep({ onComplete, existingData }: InitializationStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<InitializationValues>({
    resolver: zodResolver(initializationSchema),
    defaultValues: existingData || {
      projectTitle: "",
      projectCode: "",
      department: "",
      budget: "",
      description: "",
      initiatorName: "",
      initiatorEmail: "",
    },
  })

  async function onSubmit(values: InitializationValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="projectTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter project title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="projectCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Code</FormLabel>
                    <FormControl>
                      <Input placeholder="PRJ-001" {...field} />
                    </FormControl>
                    <FormDescription>Unique identifier for this project</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="marketing">Marketing</SelectItem>
                        <SelectItem value="sales">Sales</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="hr">HR</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Budget</FormLabel>
                    <FormControl>
                      <Input placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="initiatorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Initiator Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="initiatorEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Initiator Email</FormLabel>
                    <FormControl>
                      <Input placeholder="your.email@company.com" {...field} type="email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Provide a detailed description of the project"
                      className="min-h-24"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : "Complete & Continue"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}
