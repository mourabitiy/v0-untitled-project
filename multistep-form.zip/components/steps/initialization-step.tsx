"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import FileUploadManager from "../file-upload/file-upload-manager"
import type { FileObject, RejectionInfo } from "../../lib/types"

// Create a custom validator for files
const fileArraySchema = z
  .array(
    z.object({
      id: z.string(),
      file: z.any(),
      type: z.string().min(1, "File type must be selected"),
      progress: z.number(),
      uploaded: z.boolean(),
      error: z.string().optional(),
    }),
  )
  .refine((files) => files.length > 0, {
    message: "At least one Excel file is required",
  })
  .refine((files) => files.every((file) => file.uploaded || file.error), {
    message: "All files must be uploaded before proceeding",
  })
  .refine((files) => files.every((file) => !file.error), {
    message: "Please remove files with errors before proceeding",
  })
  .refine((files) => files.every((file) => file.type !== ""), {
    message: "All files must have a type selected",
  })

const initializationSchema = z.object({
  projectTitle: z.string().min(3, { message: "Project title must be at least 3 characters" }),
  projectCode: z.string().min(2, { message: "Project code is required" }),
  department: z.string({ required_error: "Please select a department" }),
  budget: z.string().refine((val) => !isNaN(Number.parseFloat(val)), {
    message: "Budget must be a valid number",
  }),
  description: z.string().min(20, { message: "Description must be at least 20 characters" }),
  initiatorName: z.string().min(2, { message: "Initiator name is required" }),
  initiatorEmail: z.string().email({ message: "Invalid email address" }),
  files: fileArraySchema,
})

type InitializationValues = z.infer<typeof initializationSchema>

interface InitializationStepProps {
  onComplete: (data: InitializationValues) => void
  existingData: InitializationValues | null
  rejectionInfo?: RejectionInfo
}

export default function InitializationStep({ onComplete, existingData, rejectionInfo }: InitializationStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [files, setFiles] = useState<FileObject[]>(existingData?.files || [])

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
  } = useForm<InitializationValues>({
    resolver: zodResolver(initializationSchema),
    defaultValues: existingData || {
      projectTitle: "",
      projectCode: "",
      department: "",
      budget: "",
      description: "",
      initiatorName: "",
      initiatorEmail: "",
      files: [],
    },
  })

  // Update the form value whenever files change
  useEffect(() => {
    setValue("files", files)
    trigger("files").catch(() => {
      // Handle promise rejection if validation fails
    })
  }, [files, setValue, trigger])

  async function onSubmit(values: InitializationValues) {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="card">
      <div className="card-body">
        {/* Rejection Alert */}
        {rejectionInfo && (
          <div className="alert alert-danger mb-4" role="alert">
            <div className="d-flex align-items-center mb-2">
              <span className="material-icons me-2">report_problem</span>
              <h5 className="alert-heading mb-0">Project Rejected</h5>
            </div>
            <p className="mb-2">
              <strong>Rejected by:</strong> {rejectionInfo.rejectedBy}
              <br />
              <strong>Date:</strong> {new Date(rejectionInfo.rejectedAt).toLocaleString()}
              <br />
              <strong>Step:</strong> {rejectionInfo.step}
            </p>
            <hr />
            <p className="mb-0">
              <strong>Reason for rejection:</strong>
              <br />
              {rejectionInfo.reason}
            </p>
            <div className="mt-3">
              <small className="text-muted">
                <span className="material-icons me-1" style={{ fontSize: "14px", verticalAlign: "text-bottom" }}>
                  info
                </span>
                Please address the issues mentioned above and resubmit the project.
              </small>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="row g-3 mb-3">
            <div className="col-md-6">
              <label htmlFor="projectTitle" className="form-label">
                Project Title
              </label>
              <input
                id="projectTitle"
                type="text"
                className={`form-control ${errors.projectTitle ? "is-invalid" : ""}`}
                placeholder="Enter project title"
                {...register("projectTitle")}
              />
              {errors.projectTitle && <div className="invalid-feedback">{errors.projectTitle.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="projectCode" className="form-label">
                Project Code
              </label>
              <input
                id="projectCode"
                type="text"
                className={`form-control ${errors.projectCode ? "is-invalid" : ""}`}
                placeholder="PRJ-001"
                {...register("projectCode")}
              />
              <div className="form-text">Unique identifier for this project</div>
              {errors.projectCode && <div className="invalid-feedback">{errors.projectCode.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="department" className="form-label">
                Department
              </label>
              <select
                id="department"
                className={`form-select ${errors.department ? "is-invalid" : ""}`}
                {...register("department")}
              >
                <option value="">Select department</option>
                <option value="engineering">Engineering</option>
                <option value="marketing">Marketing</option>
                <option value="sales">Sales</option>
                <option value="finance">Finance</option>
                <option value="hr">HR</option>
              </select>
              {errors.department && <div className="invalid-feedback">{errors.department.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="budget" className="form-label">
                Budget
              </label>
              <input
                id="budget"
                type="text"
                className={`form-control ${errors.budget ? "is-invalid" : ""}`}
                placeholder="0.00"
                {...register("budget")}
              />
              {errors.budget && <div className="invalid-feedback">{errors.budget.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="initiatorName" className="form-label">
                Initiator Name
              </label>
              <input
                id="initiatorName"
                type="text"
                className={`form-control ${errors.initiatorName ? "is-invalid" : ""}`}
                placeholder="Your name"
                {...register("initiatorName")}
              />
              {errors.initiatorName && <div className="invalid-feedback">{errors.initiatorName.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="initiatorEmail" className="form-label">
                Initiator Email
              </label>
              <input
                id="initiatorEmail"
                type="email"
                className={`form-control ${errors.initiatorEmail ? "is-invalid" : ""}`}
                placeholder="your.email@company.com"
                {...register("initiatorEmail")}
              />
              {errors.initiatorEmail && <div className="invalid-feedback">{errors.initiatorEmail.message}</div>}
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="description" className="form-label">
              Project Description
            </label>
            <textarea
              id="description"
              className={`form-control ${errors.description ? "is-invalid" : ""}`}
              placeholder="Provide a detailed description of the project"
              rows={4}
              {...register("description")}
            ></textarea>
            {errors.description && <div className="invalid-feedback">{errors.description.message}</div>}
          </div>

          {/* File Upload Section with validation */}
          <div className={`mb-3 ${errors.files ? "is-invalid" : ""}`}>
            <FileUploadManager files={files} setFiles={setFiles} />
            {errors.files && <div className="invalid-feedback d-block mt-2">{errors.files.message}</div>}
          </div>

          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Saving...
                </>
              ) : (
                <>
                  <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                    arrow_forward
                  </span>
                  {rejectionInfo ? "Resubmit Project" : "Complete & Continue"}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
