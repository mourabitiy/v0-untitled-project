"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { Checkbox } from "@/components/ui/checkbox"

const requestReviewSchema = z.object({
  requestorName: z.string().min(2, { message: "Requestor name is required" }),
  requestorEmail: z.string().email({ message: "Invalid email address" }),
  requestDate: z.date({ required_error: "Request date is required" }),
  priority: z.string({ required_error: "Please select a priority" }),
  additionalDocuments: z.boolean().optional(),
  reviewersEmails: z.string().min(3, { message: "At least one reviewer email is required" }),
  reviewNotes: z.string().optional(),
})

type RequestReviewValues = z.infer<typeof requestReviewSchema>

interface RequestReviewStepProps {
  onComplete: (data: RequestReviewValues) => void
  existingData: RequestReviewValues | null
}

export default function RequestReviewStep({ onComplete, existingData }: RequestReviewStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<RequestReviewValues>({
    resolver: zodResolver(requestReviewSchema),
    defaultValues: existingData || {
      requestorName: "",
      requestorEmail: "",
      requestDate: new Date(),
      priority: "",
      additionalDocuments: false,
      reviewersEmails: "",
      reviewNotes: "",
    },
  })

  async function onSubmit(values: RequestReviewValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="requestorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Requestor Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="requestorEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Requestor Email</FormLabel>
                    <FormControl>
                      <Input placeholder="your.email@company.com" {...field} type="email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="requestDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Request Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button variant={"outline"} className="pl-3 text-left font-normal">
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reviewersEmails"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reviewers (Emails)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Enter email addresses separated by commas" {...field} />
                    </FormControl>
                    <FormDescription>These people will be notified to review the request</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="additionalDocuments"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Additional Documents Required</FormLabel>
                      <FormDescription>Check if reviewers need to upload additional documents</FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="reviewNotes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes for Reviewers</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Any additional information for the reviewers"
                      className="min-h-24"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : "Complete & Continue"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}
