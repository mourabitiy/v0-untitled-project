"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon, Clock } from "lucide-react"
import { format } from "date-fns"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

const committeeSchedulingSchema = z.object({
  meetingDate: z.date({ required_error: "Meeting date is required" }),
  meetingTime: z.string({ required_error: "Meeting time is required" }),
  meetingDuration: z.string({ required_error: "Meeting duration is required" }),
  location: z.string().min(2, { message: "Location is required" }),
  room: z.string().optional(),
  virtualMeeting: z.boolean().optional(),
  meetingLink: z.string().optional(),
  schedulerName: z.string().min(2, { message: "Scheduler name is required" }),
  attendees: z.string().min(2, { message: "At least one attendee is required" }),
  agenda: z.string().min(10, { message: "Agenda must be at least 10 characters" }),
})

type CommitteeSchedulingValues = z.infer<typeof committeeSchedulingSchema>

interface CommitteeSchedulingStepProps {
  onComplete: (data: CommitteeSchedulingValues) => void
  existingData: CommitteeSchedulingValues | null
}

export default function CommitteeSchedulingStep({ onComplete, existingData }: CommitteeSchedulingStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isVirtual, setIsVirtual] = useState(existingData?.virtualMeeting || false)

  const form = useForm<CommitteeSchedulingValues>({
    resolver: zodResolver(committeeSchedulingSchema),
    defaultValues: existingData || {
      meetingDate: new Date(),
      meetingTime: "",
      meetingDuration: "",
      location: "",
      room: "",
      virtualMeeting: false,
      meetingLink: "",
      schedulerName: "",
      attendees: "",
      agenda: "",
    },
  })

  async function onSubmit(values: CommitteeSchedulingValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="meetingDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Meeting Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button variant={"outline"} className="pl-3 text-left font-normal">
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="meetingTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Meeting Time</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <Clock className="absolute right-3 top-2.5 h-4 w-4 opacity-50" />
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="meetingDuration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="30min">30 minutes</SelectItem>
                        <SelectItem value="1hour">1 hour</SelectItem>
                        <SelectItem value="1.5hours">1.5 hours</SelectItem>
                        <SelectItem value="2hours">2 hours</SelectItem>
                        <SelectItem value="3hours">3 hours</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="virtualMeeting"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={(checked) => {
                          field.onChange(checked)
                          setIsVirtual(!!checked)
                        }}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Virtual Meeting</FormLabel>
                      <FormDescription>Check if this is a virtual/online meeting</FormDescription>
                    </div>
                  </FormItem>
                )}
              />

              {isVirtual ? (
                <FormField
                  control={form.control}
                  name="meetingLink"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meeting Link</FormLabel>
                      <FormControl>
                        <Input placeholder="https://meet.company.com/123" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ) : (
                <>
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="Building/Office" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="room"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Room</FormLabel>
                        <FormControl>
                          <Input placeholder="Room number or name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}

              <FormField
                control={form.control}
                name="schedulerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Scheduler Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="attendees"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Attendees</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter names or email addresses of attendees, separated by commas"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>List all committee members and stakeholders who should attend</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="agenda"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meeting Agenda</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="List the topics to be discussed during the meeting"
                      className="min-h-24"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : "Complete & Continue"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}
