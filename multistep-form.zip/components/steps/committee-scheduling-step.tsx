"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

const committeeSchedulingSchema = z.object({
  meetingDate: z.string({ required_error: "Meeting date is required" }),
  meetingTime: z.string({ required_error: "Meeting time is required" }),
  meetingDuration: z.string({ required_error: "Meeting duration is required" }),
  location: z.string().min(2, { message: "Location is required" }).optional(),
  room: z.string().optional(),
  virtualMeeting: z.boolean().optional(),
  meetingLink: z.string().optional(),
  schedulerName: z.string().min(2, { message: "Scheduler name is required" }),
  attendees: z.string().min(2, { message: "At least one attendee is required" }),
  agenda: z.string().min(10, { message: "Agenda must be at least 10 characters" }),
})

type CommitteeSchedulingValues = z.infer<typeof committeeSchedulingSchema>

interface CommitteeSchedulingStepProps {
  onComplete: (data: CommitteeSchedulingValues) => void
  existingData: CommitteeSchedulingValues | null
}

export default function CommitteeSchedulingStep({ onComplete, existingData }: CommitteeSchedulingStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isVirtual, setIsVirtual] = useState(existingData?.virtualMeeting || false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<CommitteeSchedulingValues>({
    resolver: zodResolver(committeeSchedulingSchema),
    defaultValues: existingData || {
      meetingDate: new Date().toISOString().split("T")[0],
      meetingTime: "",
      meetingDuration: "",
      location: "",
      room: "",
      virtualMeeting: false,
      meetingLink: "",
      schedulerName: "",
      attendees: "",
      agenda: "",
    },
  })

  // Watch for changes to the virtualMeeting field
  const virtualMeeting = watch("virtualMeeting")

  async function onSubmit(values: CommitteeSchedulingValues) {
    setIsSubmitting(true)
    try {
      // Simulate async validation or processing
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onComplete(values)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="card">
      <div className="card-body">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="row g-3 mb-3">
            <div className="col-md-6">
              <label htmlFor="meetingDate" className="form-label">
                Meeting Date
              </label>
              <input
                id="meetingDate"
                type="date"
                className={`form-control ${errors.meetingDate ? "is-invalid" : ""}`}
                {...register("meetingDate")}
              />
              {errors.meetingDate && <div className="invalid-feedback">{errors.meetingDate.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="meetingTime" className="form-label">
                Meeting Time
              </label>
              <input
                id="meetingTime"
                type="time"
                className={`form-control ${errors.meetingTime ? "is-invalid" : ""}`}
                {...register("meetingTime")}
              />
              {errors.meetingTime && <div className="invalid-feedback">{errors.meetingTime.message}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="meetingDuration" className="form-label">
                Duration
              </label>
              <select
                id="meetingDuration"
                className={`form-select ${errors.meetingDuration ? "is-invalid" : ""}`}
                {...register("meetingDuration")}
              >
                <option value="">Select duration</option>
                <option value="30min">30 minutes</option>
                <option value="1hour">1 hour</option>
                <option value="1.5hours">1.5 hours</option>
                <option value="2hours">2 hours</option>
                <option value="3hours">3 hours</option>
              </select>
              {errors.meetingDuration && <div className="invalid-feedback">{errors.meetingDuration.message}</div>}
            </div>

            <div className="col-md-6">
              <div className="form-check mt-4">
                <input
                  id="virtualMeeting"
                  type="checkbox"
                  className="form-check-input"
                  {...register("virtualMeeting", {
                    onChange: () => setIsVirtual(!isVirtual),
                  })}
                />
                <label className="form-check-label" htmlFor="virtualMeeting">
                  Virtual Meeting
                </label>
                <div className="form-text">Check if this is a virtual/online meeting</div>
              </div>
            </div>

            {virtualMeeting ? (
              <div className="col-md-12">
                <label htmlFor="meetingLink" className="form-label">
                  Meeting Link
                </label>
                <input
                  id="meetingLink"
                  type="text"
                  className={`form-control ${errors.meetingLink ? "is-invalid" : ""}`}
                  placeholder="https://meet.company.com/123"
                  {...register("meetingLink")}
                />
                {errors.meetingLink && <div className="invalid-feedback">{errors.meetingLink.message}</div>}
              </div>
            ) : (
              <>
                <div className="col-md-6">
                  <label htmlFor="location" className="form-label">
                    Location
                  </label>
                  <input
                    id="location"
                    type="text"
                    className={`form-control ${errors.location ? "is-invalid" : ""}`}
                    placeholder="Building/Office"
                    {...register("location")}
                  />
                  {errors.location && <div className="invalid-feedback">{errors.location.message}</div>}
                </div>

                <div className="col-md-6">
                  <label htmlFor="room" className="form-label">
                    Room
                  </label>
                  <input
                    id="room"
                    type="text"
                    className={`form-control ${errors.room ? "is-invalid" : ""}`}
                    placeholder="Room number or name"
                    {...register("room")}
                  />
                  {errors.room && <div className="invalid-feedback">{errors.room.message}</div>}
                </div>
              </>
            )}

            <div className="col-md-6">
              <label htmlFor="schedulerName" className="form-label">
                Scheduler Name
              </label>
              <input
                id="schedulerName"
                type="text"
                className={`form-control ${errors.schedulerName ? "is-invalid" : ""}`}
                placeholder="Your name"
                {...register("schedulerName")}
              />
              {errors.schedulerName && <div className="invalid-feedback">{errors.schedulerName.message}</div>}
            </div>

            <div className="col-md-12">
              <label htmlFor="attendees" className="form-label">
                Attendees
              </label>
              <textarea
                id="attendees"
                className={`form-control ${errors.attendees ? "is-invalid" : ""}`}
                placeholder="Enter names or email addresses of attendees, separated by commas"
                rows={2}
                {...register("attendees")}
              ></textarea>
              <div className="form-text">List all committee members and stakeholders who should attend</div>
              {errors.attendees && <div className="invalid-feedback">{errors.attendees.message}</div>}
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="agenda" className="form-label">
              Meeting Agenda
            </label>
            <textarea
              id="agenda"
              className={`form-control ${errors.agenda ? "is-invalid" : ""}`}
              placeholder="List the topics to be discussed during the meeting"
              rows={4}
              {...register("agenda")}
            ></textarea>
            {errors.agenda && <div className="invalid-feedback">{errors.agenda.message}</div>}
          </div>

          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : "Complete & Continue"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
