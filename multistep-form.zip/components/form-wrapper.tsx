"use client"

import { useState, useEffect } from "react"
import FormTimeline from "./form-timeline"
import InitializationStep from "./steps/initialization-step"
import RequestReviewStep from "./steps/request-review-step"
import CommitteeSchedulingStep from "./steps/committee-scheduling-step"
import ApprovalStep from "./steps/approval-step"
import { saveFormData, updateFormStep, getFormData } from "@/lib/form-actions"
import type { FormData, FormStatus } from "@/lib/types"

// Mock initialization data for testing
const mockInitializationData = {
  projectTitle: "Customer Data Analytics Platform",
  projectCode: "CDAP-2024-001",
  department: "engineering",
  budget: "150000",
  description:
    "Development of a comprehensive customer data analytics platform to improve business intelligence and decision-making processes. This platform will integrate multiple data sources, provide real-time analytics, and offer customizable dashboards for different stakeholder groups.",
  initiatorName: "John Smith",
  initiatorEmail: "john.smith@company.com",
  files: [
    {
      id: "file-1",
      file: new File([""], "project-requirements.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      type: "excel",
      progress: 100,
      uploaded: true,
    },
    {
      id: "file-2",
      file: new File([""], "budget-breakdown.csv", { type: "text/csv" }),
      type: "csv",
      progress: 100,
      uploaded: true,
    },
    {
      id: "file-3",
      file: new File([""], "technical-specifications.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      type: "excel",
      progress: 100,
      uploaded: true,
    },
  ],
}

export default function FormWrapper() {
  const [formData, setFormData] = useState<FormData>({
    initialization: mockInitializationData,
    requestReview: null,
    committeeScheduling: null,
    approval: null,
    status: "under_review" as FormStatus, // Start with under_review to show step 2
    currentStep: 1, // This will be determined by status
    formId: crypto.randomUUID(),
    lastUpdated: new Date().toISOString(),
    lastUpdatedBy: "John Smith",
  })

  const [toast, setToast] = useState<{ show: boolean; message: string; type: string }>({
    show: false,
    message: "",
    type: "success",
  })

  const steps = [
    { name: "Initialization", component: InitializationStep },
    { name: "Request Review", component: RequestReviewStep },
    { name: "Committee Scheduling", component: CommitteeSchedulingStep },
    { name: "Approvals", component: ApprovalStep },
  ]

  // Get current step from status
  const getCurrentStepFromStatus = (status: FormStatus): number => {
    switch (status) {
      case "draft":
      case "rejected":
        return 0
      case "submitted":
      case "under_review":
        return 1
      case "approved_for_scheduling":
      case "scheduled":
        return 2
      case "final_approval":
      case "completed":
        return 3
      default:
        return 0
    }
  }

  // Update currentStep whenever status changes
  useEffect(() => {
    const newStep = getCurrentStepFromStatus(formData.status)
    if (newStep !== formData.currentStep) {
      setFormData((prev) => ({ ...prev, currentStep: newStep }))
    }
  }, [formData.status, formData.currentStep])

  const showToast = (message: string, type = "success") => {
    setToast({ show: true, message, type })
    setTimeout(() => setToast({ show: false, message: "", type: "success" }), 3000)
  }

  const loadFormData = async (formId: string) => {
    const data = await getFormData(formId)
    if (data) {
      setFormData(data)
      showToast("Form loaded successfully. Continuing from where the last team member left off.", "success")
    } else {
      showToast("Could not find form with that ID.", "danger")
    }
  }

  const handleSaveAndExit = async () => {
    await saveFormData(formData)
    showToast("Progress saved. Your teammates can continue from this point using the form ID.", "success")
  }

  // Centralized step completion handler
  const handleStepComplete = async (stepData: any) => {
    const result = await updateFormStep(formData, steps[formData.currentStep].name, stepData, "complete")

    if (result.success && result.formData) {
      setFormData(result.formData)
      showToast(result.message || "Step completed successfully", "success")
    } else {
      showToast(result.error || "Failed to complete step", "danger")
    }
  }

  // Centralized rejection handler
  const handleReviewReject = async (stepData: any) => {
    const result = await updateFormStep(formData, steps[formData.currentStep].name, stepData, "reject")

    if (result.success && result.formData) {
      setFormData(result.formData)
      showToast(result.message || "Project rejected and returned to initialization", "warning")
    } else {
      showToast(result.error || "Failed to process rejection", "danger")
    }
  }

  const CurrentStepComponent = steps[formData.currentStep].component

  // Prepare props for the current step
  const getStepProps = () => {
    const baseProps = {
      onComplete: handleStepComplete,
      existingData: formData[steps[formData.currentStep].name.toLowerCase().replace(/\s+/g, "")],
    }

    // Add special props based on step
    if (formData.currentStep === 0) {
      // Initialization step - pass rejection info if available
      return {
        ...baseProps,
        rejectionInfo: formData.rejectionInfo,
      }
    }

    if (formData.currentStep === 1) {
      // Review step - pass initialization data and reject handler
      return {
        ...baseProps,
        onReject: handleReviewReject,
        initializationData: formData.initialization,
      }
    }

    return baseProps
  }

  // Get status display info
  const getStatusInfo = () => {
    switch (formData.status) {
      case "draft":
        return { color: "secondary", text: "Draft" }
      case "submitted":
        return { color: "info", text: "Submitted" }
      case "under_review":
        return { color: "warning", text: "Under Review" }
      case "rejected":
        return { color: "danger", text: "Rejected" }
      case "approved_for_scheduling":
        return { color: "success", text: "Approved for Scheduling" }
      case "scheduled":
        return { color: "primary", text: "Scheduled" }
      case "final_approval":
        return { color: "warning", text: "Final Approval" }
      case "completed":
        return { color: "success", text: "Completed" }
      default:
        return { color: "secondary", text: "Unknown" }
    }
  }

  const statusInfo = getStatusInfo()

  return (
    <div className="mb-5">
      <FormTimeline steps={steps.map((s) => s.name)} currentStep={formData.currentStep} />

      {toast.show && (
        <div className={`alert alert-${toast.type} alert-dismissible fade show`} role="alert">
          {toast.message}
          <button type="button" className="btn-close" onClick={() => setToast({ ...toast, show: false })}></button>
        </div>
      )}

      <div className="card shadow-sm">
        <div className="card-body">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <h2 className="card-title mb-1">{steps[formData.currentStep].name}</h2>
              <span className={`badge bg-${statusInfo.color}`}>Status: {statusInfo.text}</span>
            </div>
            <div>
              <button className="btn btn-outline-secondary me-2" onClick={handleSaveAndExit}>
                <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                  save
                </span>
                Save & Exit
              </button>
              <button
                className="btn btn-outline-primary"
                onClick={() => {
                  const formId = prompt("Enter the form ID to continue")
                  if (formId) loadFormData(formId)
                }}
              >
                <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                  folder_open
                </span>
                Load Existing
              </button>
            </div>
          </div>

          <div className="py-3">
            <CurrentStepComponent {...getStepProps()} />
          </div>

          <div className="d-flex justify-content-between align-items-center mt-4">
            <div className="small text-muted">
              <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                tag
              </span>
              Form ID: {formData.formId}
            </div>

            <div className="small text-muted text-end">
              {formData.lastUpdated && (
                <>
                  <span className="material-icons me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                    update
                  </span>
                  Last updated: {new Date(formData.lastUpdated).toLocaleString()}
                </>
              )}
              {formData.lastUpdatedBy && (
                <>
                  <span className="material-icons ms-2 me-1" style={{ fontSize: "16px", verticalAlign: "text-bottom" }}>
                    person
                  </span>
                  {formData.lastUpdatedBy}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
