"use client"

import { useState } from "react"
import FormTimeline from "./form-timeline"
import InitializationStep from "./steps/initialization-step"
import RequestReviewStep from "./steps/request-review-step"
import CommitteeSchedulingStep from "./steps/committee-scheduling-step"
import ApprovalStep from "./steps/approval-step"
import { Button } from "@/components/ui/button"
import { saveFormData, submitFormStep, getFormData } from "@/lib/form-actions"
import { useToast } from "@/hooks/use-toast"
import type { FormData } from "@/lib/types"

export default function FormWrapper() {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState<FormData>({
    initialization: null,
    requestReview: null,
    committeeScheduling: null,
    approval: null,
    currentStep: 0,
    formId: crypto.randomUUID(), // Unique ID for this form
    lastUpdated: new Date().toISOString(),
    lastUpdatedBy: "",
  })
  const { toast } = useToast()

  const steps = [
    { name: "Initialization", component: InitializationStep },
    { name: "Request Review", component: RequestReviewStep },
    { name: "Committee Scheduling", component: CommitteeSchedulingStep },
    { name: "Approvals", component: ApprovalStep },
  ]

  const loadFormData = async (formId: string) => {
    const data = await getFormData(formId)
    if (data) {
      setFormData(data)
      setCurrentStep(data.currentStep)
      toast({
        title: "Form loaded successfully",
        description: "Continuing from where the last team member left off.",
      })
    }
  }

  const handleSaveAndExit = async () => {
    await saveFormData(formData)
    toast({
      title: "Progress saved",
      description: "Your teammates can continue from this point using the form ID.",
    })
  }

  const handleStepComplete = async (stepData: any) => {
    const updatedFormData = {
      ...formData,
      [steps[currentStep].name.toLowerCase().replace(/\s+/g, "")]: stepData,
      currentStep: currentStep + 1,
      lastUpdated: new Date().toISOString(),
      lastUpdatedBy: "Current User", // Would come from auth system
    }

    setFormData(updatedFormData)

    await submitFormStep(updatedFormData, steps[currentStep].name)

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
      toast({
        title: `${steps[currentStep].name} completed`,
        description: "Moving to the next step.",
      })
    } else {
      toast({
        title: "Form completed",
        description: "All steps have been successfully completed.",
      })
    }
  }

  const CurrentStepComponent = steps[currentStep].component

  return (
    <div className="space-y-8">
      <FormTimeline steps={steps.map((s) => s.name)} currentStep={currentStep} />

      <div className="bg-white p-8 rounded-lg border shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">{steps[currentStep].name}</h2>
          <div className="space-x-3">
            <Button variant="outline" onClick={handleSaveAndExit}>
              Save & Exit
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const formId = prompt("Enter the form ID to continue")
                if (formId) loadFormData(formId)
              }}
            >
              Load Existing
            </Button>
          </div>
        </div>

        <div className="py-4">
          <CurrentStepComponent
            onComplete={handleStepComplete}
            existingData={formData[steps[currentStep].name.toLowerCase().replace(/\s+/g, "")]}
          />
        </div>

        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
          >
            Previous
          </Button>

          <div className="text-sm text-muted-foreground">Form ID: {formData.formId}</div>

          <div className="text-sm text-muted-foreground">
            {formData.lastUpdated && <span>Last updated: {new Date(formData.lastUpdated).toLocaleString()}</span>}
            {formData.lastUpdatedBy && <span> by {formData.lastUpdatedBy}</span>}
          </div>
        </div>
      </div>
    </div>
  )
}
